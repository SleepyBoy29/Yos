KAMUS INGGRIS-INDONESIA (offline)

CARA PAKAI WEB
  Ekstrak zip, buka index.html di browser. Tidak perlu server atau internet.
  (Folder "data" harus tetap berada di sebelah index.html.)

DATA SIAP COPAS
  dictionary.json -> array berisi ~146 ribu entri, format:
    {"w":"house","a":"haʊs","m":[{"p":"n","d":"definisi Inggris","x":"contoh","s":["sinonim"],"i":["rumah"],"di":"definisi Indonesia"}]}
    w=kata, a=IPA (kosong jika tidak ada), m=daftar makna (maks 6),
    p=jenis kata, d=definisi, x=contoh, s=sinonim, i=padanan Indonesia, di=definisi Indonesia
  data/en-*.js, data/id-*.js -> versi per huruf yang dimuat web (bisa dibuka sebagai teks).

SUMBER & LISENSI (wajib mencantumkan atribusi bila dipublikasikan)
  - Princeton WordNet 3.0: lihat licenses/WordNet-3.0-Princeton.txt
  - Wordnet Bahasa (padanan Indonesia): MIT, lihat licenses/WordnetBahasa-MIT.txt
  - CMU Pronouncing Dictionary (pelafalan): Carnegie Mellon University, BSD-style; dikonversi ke IPA.

CATATAN KUALITAS
  Ini bukan Cambridge/Oxford. Definisi bergaya WordNet, padanan Indonesia tidak lengkap dan kadang
  memuat istilah Melayu. IPA = Inggris Amerika hasil konversi otomatis.
