-- Database schema for EPUB Store
-- Run with: psql "$DATABASE_URL" -f db/schema.sql
-- (If your database was already set up before, run db/migrate.sql instead,
--  not this file again.)

CREATE TABLE IF NOT EXISTS admins (
  id SERIAL PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Allowed categories, managed via the /admin/categories page
CREATE TABLE IF NOT EXISTS categories (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) UNIQUE NOT NULL
);

INSERT INTO categories (name) VALUES
  ('Fiction'), ('Non-Fiction'), ('Business & Economics'), ('History'),
  ('Self-Development'), ('Technology'), ('Children & Young Adult'), ('General')
ON CONFLICT (name) DO NOTHING;

-- Single-row store settings (currency + appearance colors)
CREATE TABLE IF NOT EXISTS settings (
  id INTEGER PRIMARY KEY DEFAULT 1,
  currency_code VARCHAR(10) NOT NULL DEFAULT 'USD',
  main_body_bg VARCHAR(7) NOT NULL DEFAULT '#faf7ef',
  main_header_bg VARCHAR(7) NOT NULL DEFAULT '#faf7ef',
  main_footer_bg VARCHAR(7) NOT NULL DEFAULT '#faf7ef',
  admin_header_bg VARCHAR(7) NOT NULL DEFAULT '#1e2430',
  admin_body_bg VARCHAR(7) NOT NULL DEFAULT '#faf7ef',
  admin_footer_bg VARCHAR(7) NOT NULL DEFAULT '#faf7ef',
  CONSTRAINT settings_single_row CHECK (id = 1)
);
INSERT INTO settings (id) VALUES (1) ON CONFLICT (id) DO NOTHING;

CREATE TABLE IF NOT EXISTS books (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  author VARCHAR(255) NOT NULL,
  description TEXT,
  category VARCHAR(100) NOT NULL DEFAULT 'General' REFERENCES categories(name) ON UPDATE CASCADE ON DELETE RESTRICT,
  price NUMERIC(12,2) NOT NULL DEFAULT 0,
  cover_image VARCHAR(255),
  file_format VARCHAR(20) NOT NULL DEFAULT 'EPUB',
  published_year INTEGER,
  file_size_mb NUMERIC(6,2),
  status VARCHAR(20) NOT NULL DEFAULT 'available' CHECK (status IN ('available','sold')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_books_category ON books(category);
CREATE INDEX IF NOT EXISTS idx_books_status ON books(status);
CREATE INDEX IF NOT EXISTS idx_books_created_at ON books(created_at DESC);
