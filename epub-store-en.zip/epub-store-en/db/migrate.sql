-- Migration for an EXISTING database (you already ran schema.sql before and
-- already have book data). Run this once with:
--   psql "$DATABASE_URL" -f db/migrate.sql
--
-- If this is a BRAND NEW database that's never been set up, just run
-- db/schema.sql instead — you don't need this file.

-- 1. Add published year column (if it doesn't exist yet)
ALTER TABLE books ADD COLUMN IF NOT EXISTS published_year INTEGER;

-- 2. Create the categories table
CREATE TABLE IF NOT EXISTS categories (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) UNIQUE NOT NULL
);

-- 3. Preserve any category already in use on your existing books, so
--    nothing suddenly breaks at step 5
INSERT INTO categories (name)
SELECT DISTINCT category FROM books
ON CONFLICT (name) DO NOTHING;

-- 4. Add a few general starter categories (feel free to edit/delete these
--    later on the /admin/categories page)
INSERT INTO categories (name) VALUES
  ('Fiction'), ('Non-Fiction'), ('Business & Economics'), ('History'),
  ('Self-Development'), ('Technology'), ('Children & Young Adult'), ('General')
ON CONFLICT (name) DO NOTHING;

-- 5. Add the store's currency setting (defaults to USD, changeable on the
--    /admin/settings page)
CREATE TABLE IF NOT EXISTS settings (
  id INTEGER PRIMARY KEY DEFAULT 1,
  currency_code VARCHAR(10) NOT NULL DEFAULT 'USD',
  CONSTRAINT settings_single_row CHECK (id = 1)
);
INSERT INTO settings (id, currency_code) VALUES (1, 'USD') ON CONFLICT (id) DO NOTHING;

-- 6. Add appearance color settings (body/header/footer, for both the main
--    site and the admin panel), also changeable on /admin/settings
ALTER TABLE settings ADD COLUMN IF NOT EXISTS main_body_bg VARCHAR(7) NOT NULL DEFAULT '#faf7ef';
ALTER TABLE settings ADD COLUMN IF NOT EXISTS main_header_bg VARCHAR(7) NOT NULL DEFAULT '#faf7ef';
ALTER TABLE settings ADD COLUMN IF NOT EXISTS main_footer_bg VARCHAR(7) NOT NULL DEFAULT '#faf7ef';
ALTER TABLE settings ADD COLUMN IF NOT EXISTS admin_header_bg VARCHAR(7) NOT NULL DEFAULT '#1e2430';
ALTER TABLE settings ADD COLUMN IF NOT EXISTS admin_body_bg VARCHAR(7) NOT NULL DEFAULT '#faf7ef';
ALTER TABLE settings ADD COLUMN IF NOT EXISTS admin_footer_bg VARCHAR(7) NOT NULL DEFAULT '#faf7ef';

-- 7. Lock the books.category column so it can only hold names that are
--    registered in the categories table (only runs if the constraint
--    doesn't already exist)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'books_category_fkey'
  ) THEN
    ALTER TABLE books
      ADD CONSTRAINT books_category_fkey
      FOREIGN KEY (category) REFERENCES categories(name)
      ON UPDATE CASCADE ON DELETE RESTRICT;
  END IF;
END $$;
