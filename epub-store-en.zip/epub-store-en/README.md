# EPUB Store

A catalog & sales website for a personal ebook (EPUB) collection. Simple but elegant
design, responsive on both phone and desktop. Buyers contact you directly via
WhatsApp or email — no payment gateway involved.

**Stack:** Node.js + Express + EJS (server-rendered, no build step) + PostgreSQL.

## Features

- **Public:** book catalog (a "bookshelf"-style grid), title/author search, category
  filter, detail page with "Buy via WhatsApp" / "Buy via Email" buttons.
- **Admin:** login, add/edit/delete books, upload cover images, mark status as
  available/sold, manage a controlled list of categories.
- **Store settings:** pick the display currency from a dropdown (USD, IDR, EUR, GBP,
  SGD, and more), and customize background colors for the header, page body, and
  footer — separately for the main site and the admin panel.
- **Bulk import:** scan a folder of `.epub` files and auto-import title, author,
  published year, and cover image straight from each file's metadata.

## 1. Setup

```bash
cd epub-store
npm install
cp .env.example .env
```

Edit `.env` and fill in:

| Variable | Description |
|---|---|
| `DATABASE_URL` | PostgreSQL connection string, e.g. `postgres://user:pass@localhost:5432/epub_store` |
| `PORT` | server port (default 3000) |
| `SESSION_SECRET` | random string used to encrypt the session — **must be changed** |
| `SITE_NAME`, `SITE_TAGLINE` | store name & tagline shown on the site |
| `CONTACT_WA` | WhatsApp number in international format, no `+` or spaces, e.g. `6281234567890` |
| `CONTACT_EMAIL` | email used for the "Buy via Email" button |

## 2. Create the database & tables

Create an empty PostgreSQL database (via `psql`, pgAdmin, or a service like
Supabase/Neon/Railway), then run the schema:

```bash
createdb epub_store          # if PostgreSQL is local
psql "$DATABASE_URL" -f db/schema.sql
```

> **Already set this database up before (already have book data)?**
> Don't run `schema.sql` again. Run this migration once instead:
> ```bash
> psql "$DATABASE_URL" -f db/migrate.sql
> ```
> This adds the published-year column, category table, and settings table without
> deleting any existing data.

## 3. Create an admin account

```bash
node src/scripts/create-admin.js youradmin astrongpassword123
```

Run this command again anytime to change that same admin's password, or with a
different username to create an additional admin.

## 4. Manage categories

Once logged in, open `/admin/categories` to add/remove categories. Only categories
listed here show up as options in the dropdown when adding a book — so no stray or
inconsistent categories can slip in. A category still assigned to a book can't be
deleted (move that book to another category first).

## 5. Set the currency and appearance

Open `/admin/settings` to pick the store's currency from a dropdown (USD, IDR, EUR,
GBP, SGD, and more). This changes the currency symbol shown across the whole site.
**Important:** switching currencies does **not** convert existing price values — it
only changes the symbol. If you switch from USD to IDR, a price of 15 will display
as "Rp15", not automatically recalculated to a sensible Rupiah amount. Adjust each
book's price manually after changing currency.

On the same page you can also set **appearance colors** — the header, page
background, and footer color, each configurable separately for the main site (what
buyers see) and the admin panel. Text color adjusts automatically (black or white)
so it stays readable no matter what background color you pick. Use the "Reset colors
to default" button to go back to the original look.

## 6. Bulk import from an EPUB folder (optional)

If you have a folder full of `.epub` files, you can import them automatically
(title, author, published year, and cover are read from each file's metadata):

```bash
node src/scripts/import-epubs.js "/path/to/your/epub/folder"
```

Titles already in the database (matched by title+author) are skipped, so it's safe
to run more than once. All imported books get a price of 0 and a category taken
from the file's metadata (or "General" if none) — open `/admin` to review and set
prices afterward.

## 7. Run it

```bash
npm start
```

Open:
- `http://localhost:3000` — public catalog
- `http://localhost:3000/admin/login` — admin panel

## Folder structure

```
epub-store/
├── db/
│   ├── schema.sql          # PostgreSQL schema (fresh installs)
│   └── migrate.sql         # migration for existing databases
├── public/
│   ├── css/style.css       # all styling
│   └── uploads/            # book covers uploaded/imported
└── src/
    ├── app.js              # Express entry point
    ├── db.js               # PostgreSQL connection (pg Pool)
    ├── currencies.js       # list of supported currencies
    ├── theme.js            # default appearance colors + contrast-text helper
    ├── middleware/auth.js  # protects admin pages
    ├── routes/
    │   ├── public.js       # catalog & book detail
    │   └── admin.js        # login, book CRUD, categories, settings
    ├── scripts/
    │   ├── create-admin.js
    │   └── import-epubs.js # bulk EPUB metadata importer
    └── views/               # EJS templates (public & admin pages)
```

## Deployment

Works well on services like Railway, Render, or a plain VPS (PM2 + Nginx).
Make sure to:
1. Set every environment variable from `.env.example` in your hosting dashboard.
2. Run `psql "$DATABASE_URL" -f db/schema.sql` once against the production database.
3. Run `node src/scripts/create-admin.js ...` once to create the first admin.
4. The `public/uploads` folder needs persistent disk — some PaaS platforms wipe the
   filesystem on every deploy, so consider moving covers to object storage
   (Cloudflare R2/S3) if that's your case.

## Security notes

- Replace `SESSION_SECRET` with a long random string before going live.
- Never commit the `.env` file (already in `.gitignore`).
- The admin session uses Express's default in-memory store — fine for a single
  server; if you later deploy multiple instances, switch to a persistent store
  (e.g. `connect-pg-simple`).
