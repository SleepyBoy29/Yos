// Default store appearance colors. Used when the admin hasn't set custom
// colors yet, and also as the "Reset to Default" option.
const DEFAULT_THEME = {
  main_body_bg: '#faf7ef',
  main_header_bg: '#faf7ef',
  main_footer_bg: '#faf7ef',
  admin_header_bg: '#1e2430',
  admin_body_bg: '#faf7ef',
  admin_footer_bg: '#faf7ef',
};

function isValidHex(value) {
  return typeof value === 'string' && /^#[0-9a-fA-F]{6}$/.test(value);
}

// Determines the text color (dark or light) that contrasts with a given
// background color, so text stays readable no matter what color the admin picks.
function contrastText(hex) {
  if (!isValidHex(hex)) return '#1e2430';
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  const brightness = (r * 299 + g * 587 + b * 114) / 1000;
  return brightness > 150 ? '#1e2430' : '#faf7ef';
}

module.exports = { DEFAULT_THEME, isValidHex, contrastText };
