const express = require('express');
const router = express.Router();
const pool = require('../db');

// Main catalog
router.get('/', async (req, res, next) => {
  try {
    const { q = '', category = '' } = req.query;

    const conditions = [];
    const params = [];

    if (q.trim()) {
      params.push(`%${q.trim()}%`);
      conditions.push(`(title ILIKE $${params.length} OR author ILIKE $${params.length})`);
    }
    if (category.trim()) {
      params.push(category.trim());
      conditions.push(`category = $${params.length}`);
    }

    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

    const booksResult = await pool.query(
      `SELECT * FROM books ${where} ORDER BY created_at DESC`,
      params
    );

    const categoriesResult = await pool.query(
      `SELECT DISTINCT category FROM books ORDER BY category ASC`
    );

    res.render('index', {
      books: booksResult.rows,
      categories: categoriesResult.rows.map((r) => r.category),
      query: q,
      activeCategory: category,
    });
  } catch (err) {
    next(err);
  }
});

// Book detail
router.get('/book/:id', async (req, res, next) => {
  try {
    const result = await pool.query('SELECT * FROM books WHERE id = $1', [req.params.id]);
    if (result.rows.length === 0) {
      return res.status(404).render('404');
    }
    res.render('book', { book: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
