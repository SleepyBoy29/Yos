const path = require('path');
const crypto = require('crypto');
const express = require('express');
const multer = require('multer');
const bcrypt = require('bcryptjs');
const router = express.Router();
const pool = require('../db');
const currencies = require('../currencies');
const { DEFAULT_THEME, isValidHex, contrastText } = require('../theme');
const { requireAdmin } = require('../middleware/auth');

// ---------- Cover upload configuration ----------
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, '../../public/uploads')),
  filename: (req, file, cb) => {
    const unique = crypto.randomBytes(8).toString('hex');
    cb(null, `${Date.now()}-${unique}${path.extname(file.originalname)}`);
  },
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
  fileFilter: (req, file, cb) => {
    const ok = /jpeg|jpg|png|webp/.test(file.mimetype);
    cb(ok ? null : new Error('Image must be JPG, PNG, or WEBP format.'), ok);
  },
});

// Wrap multer so errors (oversized file / wrong format) don't crash the
// page, but are caught and passed along as req.uploadError.
function uploadCover(req, res, next) {
  upload.single('cover')(req, res, (err) => {
    if (err) {
      req.uploadError =
        err.code === 'LIMIT_FILE_SIZE'
          ? 'Cover image must be under 5MB.'
          : err.message;
    }
    next();
  });
}

async function getCategoryNames() {
  const result = await pool.query('SELECT name FROM categories ORDER BY name ASC');
  return result.rows.map((r) => r.name);
}

// Combine background colors (from DB / submitted form) with their
// automatically computed contrast text colors, so the settings page always
// gets complete data — not just backgrounds missing their paired text color.
function buildThemeForView(row) {
  const base = { ...DEFAULT_THEME, ...row };
  return {
    ...base,
    main_body_text: contrastText(base.main_body_bg),
    main_header_text: contrastText(base.main_header_bg),
    main_footer_text: contrastText(base.main_footer_bg),
    admin_header_text: contrastText(base.admin_header_bg),
    admin_body_text: contrastText(base.admin_body_bg),
    admin_footer_text: contrastText(base.admin_footer_bg),
  };
}

// Validates the book form input. Returns an error message string, or null if valid.
function validateBookInput(body) {
  if (!body.title || !body.title.trim()) return 'Title is required.';
  if (!body.author || !body.author.trim()) return 'Author is required.';
  if (!body.category || !body.category.trim()) return 'Category is required.';
  const price = Number(body.price);
  if (body.price === undefined || body.price === '' || Number.isNaN(price) || price < 0) {
    return 'Price must be a number 0 or greater.';
  }
  if (body.published_year) {
    const year = Number(body.published_year);
    if (Number.isNaN(year) || year < 1000 || year > 9999) {
      return 'Published year must be a valid 4-digit number.';
    }
  }
  return null;
}

// ---------- Login ----------
router.get('/login', (req, res) => {
  if (req.session.adminId) return res.redirect('/admin');
  res.render('admin/login', { error: null });
});

router.post('/login', async (req, res, next) => {
  try {
    const { username, password } = req.body;
    const result = await pool.query('SELECT * FROM admins WHERE username = $1', [username]);
    const admin = result.rows[0];

    if (!admin || !(await bcrypt.compare(password, admin.password_hash))) {
      return res.status(401).render('admin/login', { error: 'Invalid username or password.' });
    }

    req.session.adminId = admin.id;
    req.session.adminUsername = admin.username;
    res.redirect('/admin');
  } catch (err) {
    next(err);
  }
});

router.post('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/admin/login'));
});

// ---------- Dashboard ----------
router.get('/', requireAdmin, async (req, res, next) => {
  try {
    const result = await pool.query('SELECT * FROM books ORDER BY created_at DESC');
    res.render('admin/dashboard', { books: result.rows, adminUsername: req.session.adminUsername });
  } catch (err) {
    next(err);
  }
});

// ---------- Store settings (currency & appearance) ----------
router.get('/settings', requireAdmin, async (req, res, next) => {
  try {
    const result = await pool.query('SELECT * FROM settings WHERE id = 1');
    const row = result.rows[0] || {};
    res.render('admin/settings', {
      currencies,
      currentCode: row.currency_code || 'IDR',
      theme: buildThemeForView(row),
      error: null,
      saved: false,
      adminUsername: req.session.adminUsername,
    });
  } catch (err) {
    next(err);
  }
});

router.post('/settings', requireAdmin, async (req, res, next) => {
  try {
    const { currency_code, reset_theme } = req.body;
    const isValidCurrency = currencies.some((c) => c.code === currency_code);

    if (!isValidCurrency) {
      const current = await pool.query('SELECT * FROM settings WHERE id = 1');
      return res.status(400).render('admin/settings', {
        currencies,
        currentCode: currency_code,
        theme: buildThemeForView(current.rows[0] || {}),
        error: 'The selected currency is not recognized.',
        saved: false,
        adminUsername: req.session.adminUsername,
      });
    }

    let theme;
    if (reset_theme) {
      theme = { ...DEFAULT_THEME };
    } else {
      const submitted = {
        main_body_bg: req.body.main_body_bg,
        main_header_bg: req.body.main_header_bg,
        main_footer_bg: req.body.main_footer_bg,
        admin_header_bg: req.body.admin_header_bg,
        admin_body_bg: req.body.admin_body_bg,
        admin_footer_bg: req.body.admin_footer_bg,
      };
      const invalidField = Object.entries(submitted).find(([, value]) => !isValidHex(value));
      if (invalidField) {
        const current = await pool.query('SELECT * FROM settings WHERE id = 1');
        return res.status(400).render('admin/settings', {
          currencies,
          currentCode: currency_code,
          theme: buildThemeForView(current.rows[0] || {}),
          error: 'One of the selected colors is invalid. Please use the color picker provided.',
          saved: false,
          adminUsername: req.session.adminUsername,
        });
      }
      theme = submitted;
    }

    await pool.query(
      `INSERT INTO settings (id, currency_code, main_body_bg, main_header_bg, main_footer_bg, admin_header_bg, admin_body_bg, admin_footer_bg)
       VALUES (1, $1, $2, $3, $4, $5, $6, $7)
       ON CONFLICT (id) DO UPDATE SET
         currency_code = $1, main_body_bg = $2, main_header_bg = $3, main_footer_bg = $4,
         admin_header_bg = $5, admin_body_bg = $6, admin_footer_bg = $7`,
      [
        currency_code,
        theme.main_body_bg,
        theme.main_header_bg,
        theme.main_footer_bg,
        theme.admin_header_bg,
        theme.admin_body_bg,
        theme.admin_footer_bg,
      ]
    );

    res.render('admin/settings', {
      currencies,
      currentCode: currency_code,
      theme: buildThemeForView(theme),
      error: null,
      saved: true,
      adminUsername: req.session.adminUsername,
    });
  } catch (err) {
    next(err);
  }
});

// ---------- Manage categories ----------
router.get('/categories', requireAdmin, async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT c.id, c.name, COUNT(b.id)::int AS book_count
       FROM categories c
       LEFT JOIN books b ON b.category = c.name
       GROUP BY c.id, c.name
       ORDER BY c.name ASC`
    );
    res.render('admin/categories', {
      categories: result.rows,
      error: req.query.error || null,
      adminUsername: req.session.adminUsername,
    });
  } catch (err) {
    next(err);
  }
});

router.post('/categories', requireAdmin, async (req, res, next) => {
  try {
    const name = (req.body.name || '').trim();
    if (!name) {
      return res.redirect('/admin/categories?error=' + encodeURIComponent('Category name cannot be empty.'));
    }
    await pool.query('INSERT INTO categories (name) VALUES ($1) ON CONFLICT (name) DO NOTHING', [name]);
    res.redirect('/admin/categories');
  } catch (err) {
    next(err);
  }
});

router.post('/categories/:id/delete', requireAdmin, async (req, res, next) => {
  try {
    await pool.query('DELETE FROM categories WHERE id = $1', [req.params.id]);
    res.redirect('/admin/categories');
  } catch (err) {
    if (err.code === '23503') {
      // foreign key violation: a book still uses this category
      return res.redirect(
        '/admin/categories?error=' +
          encodeURIComponent('This category is still used by a book. Move that book to another category first.')
      );
    }
    next(err);
  }
});

// ---------- Add book ----------
router.get('/book/new', requireAdmin, async (req, res, next) => {
  try {
    const categories = await getCategoryNames();
    res.render('admin/form', { book: null, error: null, categories, isEdit: false, bookId: null });
  } catch (err) {
    next(err);
  }
});

router.post('/book', requireAdmin, uploadCover, async (req, res, next) => {
  try {
    const categories = await getCategoryNames();

    if (req.uploadError) {
      return res.status(400).render('admin/form', {
        book: req.body,
        error: req.uploadError,
        categories,
        isEdit: false,
        bookId: null,
      });
    }

    const validationError = validateBookInput(req.body);
    if (validationError) {
      return res.status(400).render('admin/form', {
        book: req.body,
        error: validationError,
        categories,
        isEdit: false,
        bookId: null,
      });
    }

    const { title, author, description, category, price, file_size_mb, published_year, status } = req.body;
    const cover_image = req.file ? `/uploads/${req.file.filename}` : null;

    await pool.query(
      `INSERT INTO books (title, author, description, category, price, cover_image, file_size_mb, published_year, status)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
      [
        title.trim(),
        author.trim(),
        description || null,
        category,
        price,
        cover_image,
        file_size_mb || null,
        published_year || null,
        status || 'available',
      ]
    );

    res.redirect('/admin');
  } catch (err) {
    next(err);
  }
});

// ---------- Edit book ----------
router.get('/book/:id/edit', requireAdmin, async (req, res, next) => {
  try {
    const result = await pool.query('SELECT * FROM books WHERE id = $1', [req.params.id]);
    if (result.rows.length === 0) return res.status(404).render('404');
    const categories = await getCategoryNames();
    res.render('admin/form', {
      book: result.rows[0],
      error: null,
      categories,
      isEdit: true,
      bookId: req.params.id,
    });
  } catch (err) {
    next(err);
  }
});

router.put('/book/:id', requireAdmin, uploadCover, async (req, res, next) => {
  try {
    const categories = await getCategoryNames();

    if (req.uploadError) {
      return res.status(400).render('admin/form', {
        book: { ...req.body, id: req.params.id },
        error: req.uploadError,
        categories,
        isEdit: true,
        bookId: req.params.id,
      });
    }

    const validationError = validateBookInput(req.body);
    if (validationError) {
      return res.status(400).render('admin/form', {
        book: { ...req.body, id: req.params.id },
        error: validationError,
        categories,
        isEdit: true,
        bookId: req.params.id,
      });
    }

    const { title, author, description, category, price, file_size_mb, published_year, status } = req.body;

    const existing = await pool.query('SELECT cover_image FROM books WHERE id = $1', [req.params.id]);
    if (existing.rows.length === 0) return res.status(404).render('404');

    const cover_image = req.file ? `/uploads/${req.file.filename}` : existing.rows[0].cover_image;

    await pool.query(
      `UPDATE books SET title=$1, author=$2, description=$3, category=$4, price=$5,
       cover_image=$6, file_size_mb=$7, published_year=$8, status=$9, updated_at=now()
       WHERE id=$10`,
      [
        title.trim(),
        author.trim(),
        description || null,
        category,
        price,
        cover_image,
        file_size_mb || null,
        published_year || null,
        status || 'available',
        req.params.id,
      ]
    );

    res.redirect('/admin');
  } catch (err) {
    next(err);
  }
});

// ---------- Delete book ----------
router.delete('/book/:id', requireAdmin, async (req, res, next) => {
  try {
    await pool.query('DELETE FROM books WHERE id = $1', [req.params.id]);
    res.redirect('/admin');
  } catch (err) {
    next(err);
  }
});

module.exports = router;
