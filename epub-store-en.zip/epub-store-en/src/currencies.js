// List of currencies the store can be set to. Add a new line here if you
// need another currency later.
module.exports = [
  { code: 'IDR', label: 'Indonesian Rupiah (IDR)', symbol: 'Rp', locale: 'id-ID' },
  { code: 'USD', label: 'US Dollar (USD)', symbol: '$', locale: 'en-US' },
  { code: 'EUR', label: 'Euro (EUR)', symbol: '€', locale: 'en-IE' },
  { code: 'GBP', label: 'British Pound (GBP)', symbol: '£', locale: 'en-GB' },
  { code: 'SGD', label: 'Singapore Dollar (SGD)', symbol: 'S$', locale: 'en-SG' },
  { code: 'MYR', label: 'Malaysian Ringgit (MYR)', symbol: 'RM', locale: 'ms-MY' },
  { code: 'AUD', label: 'Australian Dollar (AUD)', symbol: 'A$', locale: 'en-AU' },
  { code: 'JPY', label: 'Japanese Yen (JPY)', symbol: '¥', locale: 'ja-JP' },
  { code: 'CNY', label: 'Chinese Yuan (CNY)', symbol: '¥', locale: 'zh-CN' },
  { code: 'INR', label: 'Indian Rupee (INR)', symbol: '₹', locale: 'en-IN' },
  { code: 'PHP', label: 'Philippine Peso (PHP)', symbol: '₱', locale: 'en-PH' },
  { code: 'THB', label: 'Thai Baht (THB)', symbol: '฿', locale: 'th-TH' },
  { code: 'VND', label: 'Vietnamese Dong (VND)', symbol: '₫', locale: 'vi-VN' },
];
