// Scans a folder of EPUB files and auto-imports title, author, year, and cover into the database.
// Usage: node src/scripts/import-epubs.js "D:\path\to\epub\folder"
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const AdmZip = require('adm-zip');
const xml2js = require('xml2js');
const pool = require('../db');

const UPLOAD_DIR = path.join(__dirname, '../../public/uploads');

function toArray(value) {
  if (value === undefined || value === null) return [];
  return Array.isArray(value) ? value : [value];
}

function extractYear(dateStr) {
  if (!dateStr) return null;
  const match = String(dateStr).match(/\d{4}/);
  return match ? parseInt(match[0], 10) : null;
}

function extFromMediaType(mediaType) {
  const map = {
    'image/jpeg': '.jpg',
    'image/png': '.png',
    'image/webp': '.webp',
    'image/gif': '.gif',
  };
  return map[mediaType] || '.jpg';
}

// Reads a single .epub file and returns its metadata + cover buffer (if any)
async function readEpub(filePath) {
  const zip = new AdmZip(filePath);
  const parser = new xml2js.Parser({ explicitArray: false });

  // 1. Read container.xml to find the location of the .opf file
  const containerEntry = zip.getEntry('META-INF/container.xml');
  if (!containerEntry) throw new Error('container.xml not found (not a valid EPUB)');
  const containerXml = await parser.parseStringPromise(zip.readAsText(containerEntry));
  const opfPath = containerXml.container.rootfiles.rootfile.$['full-path'];

  // 2. Read the .opf file for metadata & manifest
  const opfEntry = zip.getEntry(opfPath);
  if (!opfEntry) throw new Error(`OPF file not found: ${opfPath}`);
  const opfXml = await parser.parseStringPromise(zip.readAsText(opfEntry));
  const pkg = opfXml.package;
  const metadata = pkg.metadata;
  const manifestItems = toArray(pkg.manifest.item);
  const opfDir = path.posix.dirname(opfPath);

  const title = toArray(metadata['dc:title'])[0] || path.basename(filePath, '.epub');
  const authors = toArray(metadata['dc:creator']).map((c) => (typeof c === 'string' ? c : c._));
  const author = authors.length ? authors.join(', ') : 'Unknown';
  const dateRaw = toArray(metadata['dc:date'])[0];
  const year = extractYear(typeof dateRaw === 'string' ? dateRaw : dateRaw && dateRaw._);
  const subjects = toArray(metadata['dc:subject']);
  const category = subjects.length ? (typeof subjects[0] === 'string' ? subjects[0] : subjects[0]._) : 'General';
  const descriptionRaw = toArray(metadata['dc:description'])[0];
  const description = typeof descriptionRaw === 'string' ? descriptionRaw : descriptionRaw && descriptionRaw._;

  // 3. Find the cover image: try the EPUB3 way first, then EPUB2, then a last-resort guess
  let coverItem = manifestItems.find(
    (item) => item.$.properties && item.$.properties.split(' ').includes('cover-image')
  );

  if (!coverItem) {
    const metaTags = toArray(metadata.meta);
    const coverMeta = metaTags.find((m) => m.$ && m.$.name === 'cover');
    if (coverMeta) {
      coverItem = manifestItems.find((item) => item.$.id === coverMeta.$.content);
    }
  }

  if (!coverItem) {
    coverItem = manifestItems.find(
      (item) =>
        item.$['media-type'] &&
        item.$['media-type'].startsWith('image/') &&
        /cover/i.test(item.$.id + item.$.href)
    );
  }

  let coverBuffer = null;
  let coverExt = '.jpg';
  if (coverItem) {
    const coverPath = path.posix.normalize(path.posix.join(opfDir, coverItem.$.href));
    const coverEntry = zip.getEntry(coverPath);
    if (coverEntry) {
      coverBuffer = zip.readFile(coverEntry);
      coverExt = extFromMediaType(coverItem.$['media-type']);
    }
  }

  return { title, author, year, category, description, coverBuffer, coverExt };
}

async function importFolder(folderPath) {
  if (!fs.existsSync(folderPath)) {
    console.log(`Folder not found: ${folderPath}`);
    process.exit(1);
  }
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });

  const files = fs.readdirSync(folderPath).filter((f) => f.toLowerCase().endsWith('.epub'));
  if (files.length === 0) {
    console.log('No .epub files found in this folder.');
    return;
  }

  console.log(`Found ${files.length} .epub file(s). Processing...\n`);

  let imported = 0;
  let skipped = 0;
  let failed = 0;

  for (const file of files) {
    const fullPath = path.join(folderPath, file);
    try {
      const meta = await readEpub(fullPath);

      // Skip if the same title + author already exists in the database
      const existing = await pool.query(
        'SELECT id FROM books WHERE title = $1 AND author = $2',
        [meta.title, meta.author]
      );
      if (existing.rows.length > 0) {
        console.log(`⏭  Skipped (already exists): ${meta.title}`);
        skipped++;
        continue;
      }

      let coverImage = null;
      if (meta.coverBuffer) {
        const filename = `${Date.now()}-${crypto.randomBytes(6).toString('hex')}${meta.coverExt}`;
        fs.writeFileSync(path.join(UPLOAD_DIR, filename), meta.coverBuffer);
        coverImage = `/uploads/${filename}`;
      }

      const sizeMb = Math.round((fs.statSync(fullPath).size / (1024 * 1024)) * 100) / 100;

      await pool.query(
        `INSERT INTO books
          (title, author, description, category, price, cover_image, file_format, file_size_mb, published_year, status)
         VALUES ($1,$2,$3,$4,0,$5,'EPUB',$6,$7,'available')`,
        [meta.title, meta.author, meta.description || null, meta.category, coverImage, sizeMb, meta.year]
      );

      console.log(`✅ Imported: ${meta.title} (${meta.year || 'unknown year'})${coverImage ? '' : ' — no cover'}`);
      imported++;
    } catch (err) {
      console.log(`❌ Failed to process "${file}": ${err.message}`);
      failed++;
    }
  }

  console.log(`\nDone. ${imported} imported, ${skipped} skipped (duplicates), ${failed} failed.`);
  console.log('Price is set to 0 for all newly imported books — open /admin to set prices and review the data.');
}

const folderArg = process.argv[2];
if (!folderArg) {
  console.log('Usage: node src/scripts/import-epubs.js "path/to/epub/folder"');
  process.exit(1);
}

importFolder(folderArg)
  .then(() => process.exit(0))
  .catch((err) => {
    console.error('An error occurred:', err.message);
    process.exit(1);
  });
