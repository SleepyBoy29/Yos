// Creates or updates the admin account.
// Usage: node src/scripts/create-admin.js <username> <password>
require('dotenv').config();
const bcrypt = require('bcryptjs');
const pool = require('../db');

async function main() {
  const [, , username, password] = process.argv;

  if (!username || !password) {
    console.log('Usage: node src/scripts/create-admin.js <username> <password>');
    process.exit(1);
  }
  if (password.length < 6) {
    console.log('Password must be at least 6 characters.');
    process.exit(1);
  }

  const hash = await bcrypt.hash(password, 10);

  await pool.query(
    `INSERT INTO admins (username, password_hash)
     VALUES ($1, $2)
     ON CONFLICT (username) DO UPDATE SET password_hash = $2`,
    [username, hash]
  );

  console.log(`Admin "${username}" created/updated successfully.`);
  process.exit(0);
}

main().catch((err) => {
  console.error('Failed to create admin:', err.message);
  process.exit(1);
});
