require('dotenv').config();
const path = require('path');
const express = require('express');
const session = require('express-session');
const methodOverride = require('method-override');

const pool = require('./db');
const currencies = require('./currencies');
const { DEFAULT_THEME, contrastText } = require('./theme');
const publicRoutes = require('./routes/public');
const adminRoutes = require('./routes/admin');

const app = express();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(methodOverride('_method'));
app.use(express.static(path.join(__dirname, '../public')));

app.use(
  session({
    secret: process.env.SESSION_SECRET || 'replace-this-secret',
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 1000 * 60 * 60 * 8 }, // 8 hours
  })
);

// Global data for all views
app.use(async (req, res, next) => {
  res.locals.siteName = process.env.SITE_NAME || 'Digital Library';
  res.locals.siteTagline = process.env.SITE_TAGLINE || 'A curated ebook collection';
  res.locals.contactWa = process.env.CONTACT_WA || '';
  res.locals.contactEmail = process.env.CONTACT_EMAIL || '';

  let currency = currencies[0]; // fallback: IDR
  let theme = { ...DEFAULT_THEME };
  try {
    const result = await pool.query(
      'SELECT currency_code, main_body_bg, main_header_bg, main_footer_bg, admin_header_bg, admin_body_bg, admin_footer_bg FROM settings WHERE id = 1'
    );
    const row = result.rows[0];
    if (row) {
      const code = row.currency_code;
      currency = currencies.find((c) => c.code === code) || currency;
      theme = {
        main_body_bg: row.main_body_bg || DEFAULT_THEME.main_body_bg,
        main_header_bg: row.main_header_bg || DEFAULT_THEME.main_header_bg,
        main_footer_bg: row.main_footer_bg || DEFAULT_THEME.main_footer_bg,
        admin_header_bg: row.admin_header_bg || DEFAULT_THEME.admin_header_bg,
        admin_body_bg: row.admin_body_bg || DEFAULT_THEME.admin_body_bg,
        admin_footer_bg: row.admin_footer_bg || DEFAULT_THEME.admin_footer_bg,
      };
    }
  } catch (err) {
    // settings table doesn't exist yet / not migrated — keep defaults
  }

  res.locals.currency = currency;
  res.locals.formatPrice = (value) =>
    currency.symbol + Number(value || 0).toLocaleString(currency.locale, { maximumFractionDigits: 2 });

  res.locals.theme = {
    ...theme,
    main_body_text: contrastText(theme.main_body_bg),
    main_header_text: contrastText(theme.main_header_bg),
    main_footer_text: contrastText(theme.main_footer_bg),
    admin_header_text: contrastText(theme.admin_header_bg),
    admin_body_text: contrastText(theme.admin_body_bg),
    admin_footer_text: contrastText(theme.admin_footer_bg),
  };

  next();
});

app.use('/', publicRoutes);
app.use('/admin', adminRoutes);

app.use((req, res) => {
  res.status(404).render('404');
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).send('A server error occurred. Please try again.');
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`EPUB Store running at http://localhost:${PORT}`);
});

