#!/usr/bin/env bash
set -u
cd "$(dirname "$0")"

echo "============================================================"
echo "             EPUB BATCH PROCESSOR - NODE.JS"
echo "============================================================"
echo

if ! command -v node >/dev/null 2>&1; then
    echo "[ERROR] Node.js tidak ditemukan."
    echo "Install Node.js terlebih dahulu."
    exit 1
fi

if [ ! -d "node_modules" ]; then
    echo "[INFO] node_modules belum ada."
    echo "[INFO] Menjalankan npm install..."
    npm install || exit 1
    echo
fi

npm run process
rc=$?

echo
echo "============================================================"
echo "Proses selesai."
echo "============================================================"

exit "$rc"
