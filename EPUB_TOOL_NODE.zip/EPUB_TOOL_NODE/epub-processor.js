const fs = require("fs");
const path = require("path");
const os = require("os");
const AdmZip = require("adm-zip");
const { XMLParser } = require("fast-xml-parser");

const BASE = __dirname;
const CONFIG_FILE = path.join(BASE, "config.json");
const config = JSON.parse(fs.readFileSync(CONFIG_FILE, "utf8"));

const SOURCE = path.resolve(BASE, config.directories.source);
const RESULT_EPUB = path.resolve(BASE, config.directories.renameResult);
const RESULT_COVER = path.resolve(BASE, config.directories.coverResult);

const HTML_EXTENSIONS = new Set([".html", ".htm", ".xhtml"]);

function ensureDirs() {
  [SOURCE, RESULT_EPUB, RESULT_COVER].forEach(d => fs.mkdirSync(d, { recursive: true }));
}

function outputName(filename) {
  let name = filename;

  // Remove OceanofPDF.com prefix plus surrounding underscores/spaces.
  //
  // Examples:
  // _OceanofPDF.com_The_Book.epub
  // OceanofPDF.com_The_Book.epub
  // __OceanofPDF.com__The_Book.epub
  //
  // Become:
  // The_Book.epub

  name = name.replace(
    /^[_\s]*OceanofPDF\.com[_\s]*/i,
    ""
  );

  return name;
}

function escapeRegex(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function removeConfiguredHtml(text) {
  let result = text;
  let removed = 0;

  for (const item of (config.html?.removePatterns || [])) {
    if (!item.pattern) continue;
    const regex = new RegExp(escapeRegex(item.pattern), "gi");
    const matches = result.match(regex);
    if (matches) {
      removed += matches.length;
      result = result.replace(regex, "");
    }
  }

  return { text: result, removed };
}

function safeZipPath(p) {
  p = p.replace(/\\/g, "/");
  const parts = [];
  for (const part of p.split("/")) {
    if (!part || part === ".") continue;
    if (part === "..") parts.pop();
    else parts.push(part);
  }
  return parts.join("/");
}

function decodeXml(value) {
  return String(value)
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'");
}

function extractCover(epubPath, outputBase) {
  const zip = new AdmZip(epubPath);
  const entries = zip.getEntries();
  const names = entries.map(e => e.entryName.replace(/\\/g, "/"));

  let opfPath = null;
  const containerEntry = zip.getEntry("META-INF/container.xml");

  if (containerEntry) {
    const containerXml = containerEntry.getData().toString("utf8");
    const match = containerXml.match(/full-path\s*=\s*["']([^"']+\.opf)["']/i);
    if (match) opfPath = safeZipPath(match[1]);
  }

  let coverEntryName = null;

  if (opfPath) {
    const opfEntry = zip.getEntry(opfPath);
    if (opfEntry) {
      const opf = opfEntry.getData().toString("utf8");
      const opfDir = path.posix.dirname(opfPath);

      // EPUB3: properties="cover-image"
      let match = opf.match(/<item\b[^>]*href\s*=\s*["']([^"']+)["'][^>]*properties\s*=\s*["'][^"']*\bcover-image\b[^"']*["'][^>]*>/i);
      if (!match) {
        match = opf.match(/<item\b(?=[^>]*properties\s*=\s*["'][^"']*\bcover-image\b[^"']*["'])(?=[^>]*href\s*=\s*["']([^"']+)["'])[^>]*>/i);
      }

      if (match) {
        const candidate = safeZipPath(path.posix.join(opfDir === "." ? "" : opfDir, decodeXml(match[1])));
        if (names.includes(candidate)) coverEntryName = candidate;
      }

      // EPUB2: <meta name="cover" content="cover-image-id">
      if (!coverEntryName) {
        const meta1 = opf.match(/<meta\b[^>]*name\s*=\s*["']cover["'][^>]*content\s*=\s*["']([^"']+)["'][^>]*>/i);
        const meta2 = opf.match(/<meta\b[^>]*content\s*=\s*["']([^"']+)["'][^>]*name\s*=\s*["']cover["'][^>]*>/i);
        const coverId = meta1 ? meta1[1] : (meta2 ? meta2[1] : null);

        if (coverId) {
          const itemRegex = new RegExp(
            `<item\\\\b(?=[^>]*\\\\bid\\\\s*=\\\\s*["']${escapeRegex(coverId)}["'])(?=[^>]*\\\\bhref\\\\s*=\\\\s*["']([^"']+)["'])[^>]*>`,
            "i"
          );
          const item = opf.match(itemRegex);
          if (item) {
            const candidate = safeZipPath(path.posix.join(opfDir === "." ? "" : opfDir, decodeXml(item[1])));
            if (names.includes(candidate)) coverEntryName = candidate;
          }
        }
      }
    }
  }

  // Fallback: prefer filenames containing "cover".
  if (!coverEntryName) {
    const images = names.filter(n => /\.(jpe?g|png|webp)$/i.test(n));
    images.sort((a, b) => {
      const ac = /cover/i.test(path.posix.basename(a)) ? 0 : 1;
      const bc = /cover/i.test(path.posix.basename(b)) ? 0 : 1;
      return ac - bc || a.length - b.length;
    });
    coverEntryName = images[0] || null;
  }

  if (!coverEntryName) return null;

  const entry = zip.getEntry(coverEntryName);
  if (!entry) return null;

  const ext = path.extname(coverEntryName).toLowerCase();
  const allowed = new Set([".jpg", ".jpeg", ".png", ".webp"]);
  const finalExt = allowed.has(ext) ? ext : ".jpg";
  const output = outputBase + finalExt;

  for (const e of [".jpg", ".jpeg", ".png", ".webp"]) {
    const old = outputBase + e;
    if (fs.existsSync(old)) fs.unlinkSync(old);
  }

  fs.writeFileSync(output, entry.getData());
  return path.basename(output);
}

function cleanEpub(srcPath, destPath) {
  const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), "epub-tool-"));

  try {
    const zip = new AdmZip(srcPath);
    zip.extractAllTo(tempDir, true);

    let removed = 0;

    function walk(dir) {
      for (const item of fs.readdirSync(dir, { withFileTypes: true })) {
        const full = path.join(dir, item.name);
        if (item.isDirectory()) walk(full);
        else if (HTML_EXTENSIONS.has(path.extname(item.name).toLowerCase())) {
          const original = fs.readFileSync(full, "utf8");
          const cleaned = removeConfiguredHtml(original);
          if (cleaned.removed > 0) {
            fs.writeFileSync(full, cleaned.text, "utf8");
            removed += cleaned.removed;
          }
        }
      }
    }

    walk(tempDir);

    const outZip = new AdmZip();
    const mimetype = path.join(tempDir, "mimetype");

    // EPUB requirement: mimetype must be first and uncompressed.
    if (fs.existsSync(mimetype)) {
      outZip.addFile("mimetype", fs.readFileSync(mimetype), "", 0);
    }

    function addDirectory(dir, relBase = "") {
      for (const item of fs.readdirSync(dir, { withFileTypes: true })) {
        const full = path.join(dir, item.name);
        const rel = relBase ? path.posix.join(relBase, item.name) : item.name;
        if (rel === "mimetype") continue;
        if (item.isDirectory()) addDirectory(full, rel);
        else outZip.addLocalFile(full, path.posix.dirname(rel) === "." ? "" : path.posix.dirname(rel), path.basename(rel));
      }
    }

    addDirectory(tempDir);
    outZip.writeZip(destPath);

    return removed;
  } finally {
    fs.rmSync(tempDir, { recursive: true, force: true });
  }
}

function main() {
  ensureDirs();

  const epubs = fs.readdirSync(SOURCE)
    .filter(f => f.toLowerCase().endsWith(".epub"))
    .sort((a, b) => a.localeCompare(b));

  console.log("============================================================");
  console.log("              EPUB BATCH PROCESSOR - NODE.JS");
  console.log("============================================================");
  console.log(`Source : ${SOURCE}`);
  console.log(`EPUB   : ${RESULT_EPUB}`);
  console.log(`Cover  : ${RESULT_COVER}`);
  console.log(`Jumlah : ${epubs.length}`);
  console.log("");

  if (epubs.length === 0) {
    console.log("Tidak ada file .epub di folder source.");
    return;
  }

  let success = 0;
  let failed = 0;

  for (let i = 0; i < epubs.length; i++) {
    const filename = epubs[i];
    const src = path.join(SOURCE, filename);
    const newName = outputName(filename);
    const dest = path.join(RESULT_EPUB, newName);

    console.log(`[${i + 1}/${epubs.length}] ${filename}`);

    try {
      const removed = cleanEpub(src, dest);
      const cover = extractCover(dest, path.join(RESULT_COVER, path.parse(newName).name));

      console.log(`  EPUB   : ${newName}`);
      console.log(`  HTML   : ${removed} fragment dihapus`);
      console.log(`  COVER  : ${cover || "tidak ditemukan"}`);
      console.log("  STATUS : OK");
      success++;
    } catch (err) {
      console.log(`  STATUS : GAGAL`);
      console.log(`  ERROR  : ${err.message}`);
      failed++;
    }

    console.log("");
  }

  console.log("============================================================");
  console.log(`SELESAI | Berhasil: ${success} | Gagal: ${failed}`);
  console.log("============================================================");
}

main();
