@echo off
setlocal
cd /d "%~dp0"
title EPUB Batch Processor - Node.js

echo ============================================================
echo              EPUB BATCH PROCESSOR - NODE.JS
echo ============================================================
echo.

where node >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Node.js tidak ditemukan.
    echo Install Node.js terlebih dahulu.
    pause
    exit /b 1
)

if not exist node_modules (
    echo [INFO] node_modules belum ada.
    echo [INFO] Menjalankan npm install...
    echo.
    call npm install
    if errorlevel 1 (
        echo.
        echo [ERROR] npm install gagal.
        pause
        exit /b 1
    )
    echo.
)

call npm run process

echo.
echo ============================================================
echo Proses selesai.
echo ============================================================
pause
endlocal
