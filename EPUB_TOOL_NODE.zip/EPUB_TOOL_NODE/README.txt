EPUB BATCH PROCESSOR - NODE.JS
==============================

KEBUTUHAN
---------
- Node.js 18+ direkomendasikan
- npm (biasanya ikut terinstall bersama Node.js)
- Tidak membutuhkan Python


STRUKTUR
--------
EPUB_TOOL/
├── source/
├── resource_rename/
├── result_rename_epub/
├── result/
├── config.json
├── package.json
├── epub-processor.js
├── process_epub.bat
├── process_epub.sh
└── README.txt


CARA WINDOWS
------------
1. Masukkan satu atau banyak file .epub ke folder source/
2. Double-click process_epub.bat
3. Jika pertama kali dijalankan, script otomatis menjalankan:
       npm install
4. Hasil EPUB ada di:
       result_rename_epub/
5. Cover ada di:
       result/


CARA LINUX
----------
1. Masukkan EPUB ke source/
2. Jalankan:
       chmod +x process_epub.sh
       ./process_epub.sh

Atau:
       npm install
       npm run process


RENAME
------
config.json berisi:

"removePrefixes": [
  "OceanofPDF.com_"
]

Contoh:
OceanofPDF.com_The_Ten_Commandments_-_Kevin_DeYoung.epub

menjadi:
The_Ten_Commandments_-_Kevin_DeYoung.epub


PEMBERSIHAN HTML
----------------
Pola HTML yang ingin dibersihkan berada di config.json pada:
html.removePatterns

Anda dapat menambahkan pola lain sesuai kebutuhan dan hak modifikasi Anda.


MULTIPLE EPUB
-------------
Semua file .epub yang berada di source/ akan diproses satu per satu.

Contoh:
source/
├── Book_A.epub
├── Book_B.epub
├── Book_C.epub
└── Book_D.epub

Semua diproses dalam satu kali menjalankan script.


ORIGINAL FILE
-------------
File di source/ tidak pernah ditimpa.


COVER
-----
Script mencoba mencari cover berdasarkan metadata EPUB:
- EPUB3 properties="cover-image"
- EPUB2 meta name="cover"

Jika metadata tidak ditemukan, script melakukan fallback ke file gambar
yang namanya mengandung "cover", lalu ke gambar pertama yang ditemukan.


CATATAN
-------
Folder resource_rename disediakan untuk kebutuhan pengembangan berikutnya.
Script tidak membutuhkan folder tersebut untuk proses dasar.


VERSI PERBAIKAN RENAME
----------------------
Versi ini memperbaiki filename seperti:
_OceanofPDF.com_The_Ten_Commandments_-_Kevin_DeYoung.epub

menjadi:
The_Ten_Commandments_-_Kevin_DeYoung.epub

Variasi underscore/spasi di sekitar OceanofPDF.com juga ditangani.
Underscore yang merupakan bagian dari judul buku tetap dipertahankan.
