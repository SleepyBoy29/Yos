# Calico Kitten Buddy — for Firefox

A floating animated calico kitten character.

## Features
- Idle bounce animation when just sitting there
- **Drag & drop** — click and hold, then move it anywhere on the page
- **Click** it (without dragging) to get a random tip in English
- **Autonomous behavior** — when you leave it alone for a while, it will randomly:
  - 🚶 Walk left/right across the screen (faces the direction it's moving)
  - 🎉 Play (a little spin/hop)
  - 💤 Sleep (eyes close, "Zzz" appears)
  - ❤️ Show happiness (jumps a few times)

## Install on Firefox
1. Unzip this folder.
2. Open `about:debugging#/runtime/this-firefox` in the address bar.
3. Click **Load Temporary Add-on…**
4. Select the `manifest.json` file inside the unzipped `clippy-firefox` folder.
5. Open any website to see kitten appear.

Note: Temporary add-ons are removed when Firefox restarts. For a permanent
install, the extension needs to be signed via https://addons.mozilla.org.

## Customize
- Edit the `TIPS` array in `content.js` to change what it says when clicked.
- Adjust timing in `activityLoop()` (`rand(6000, 13000)`) to make it more or less active.
- Edit `content.css` to change size, colors, or animation speed.
