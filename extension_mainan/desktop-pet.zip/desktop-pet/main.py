#!/usr/bin/env python3
"""
Desktop Pet launcher.

Usage:
    python main.py
    python main.py --pet calico_kitten
    python main.py --scale 2.0

Requires: Python 3.8+, Pillow (pip install -r requirements.txt).
On Linux you may also need the Tk bindings: sudo apt install python3-tk
"""
import argparse
import sys

from pet.app import PetApp


def main():
    parser = argparse.ArgumentParser(description="Run the desktop pet.")
    parser.add_argument(
        "--pet", dest="pet_name", default=None,
        help="Name of the sprite folder under sprites/ to use (default: calico_kitten).",
    )
    parser.add_argument(
        "--scale", dest="scale", type=float, default=None,
        help="Sprite size multiplier (default: 1.6).",
    )
    args = parser.parse_args()

    try:
        app = PetApp(pet_name=args.pet_name, sprite_scale=args.scale)
    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    app.run()


if __name__ == "__main__":
    main()
