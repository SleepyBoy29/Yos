@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if %ERRORLEVEL%==0 (
    set PYTHON=py
) else (
    set PYTHON=python
)

if not exist ".venv" (
    echo Creating virtual environment...
    %PYTHON% -m venv .venv
)

call .venv\Scripts\activate.bat
pip show pillow >nul 2>nul
if errorlevel 1 (
    echo Installing dependencies...
    pip install -r requirements.txt
)

python main.py %*
