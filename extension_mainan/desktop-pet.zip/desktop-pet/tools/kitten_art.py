"""
Generates the sample calico-kitten sprite art used as default/demo sprites.
This is only used by generate_sprites.py — the running app never imports this
module. Replace the generated PNGs under sprites/calico_kitten/ with your own
artwork any time; this script is just here so the pet works out of the box.
"""
from PIL import Image, ImageDraw

CREAM = (251, 243, 230, 255)
ORANGE = (232, 148, 68, 255)
BLACK = (40, 32, 26, 255)
PINK = (247, 169, 192, 255)
PINK_CHEEK = (246, 174, 192, 180)

R = 26.0
CX, CY = 50.0, 44.0
BODY_CX, BODY_CY = CX, CY + R * 1.55
BODY_RX, BODY_RY = R * 0.95, R * 0.90


def _bezier(p0, p1, p2, p3, n):
    pts = []
    for i in range(n + 1):
        t = i / n
        x = (1 - t) ** 3 * p0[0] + 3 * (1 - t) ** 2 * t * p1[0] + 3 * (1 - t) * t ** 2 * p2[0] + t ** 3 * p3[0]
        y = (1 - t) ** 3 * p0[1] + 3 * (1 - t) ** 2 * t * p1[1] + 3 * (1 - t) * t ** 2 * p2[1] + t ** 3 * p3[1]
        pts.append((x, y))
    return pts


def draw_kitten(eye_mode="open", mouth_mode="smile", bob=0.0, size=300, supersample=3):
    """
    eye_mode: 'open' | 'blink' | 'happy' (curved ^ ^ eyes)
    mouth_mode: 'smile' | 'open'
    bob: vertical offset in viewBox units, for a subtle breathing/bounce frame
    """
    S = supersample
    canvas_w = int(100 * size / 100) * S
    canvas_h = int(120 * size / 100) * S
    img = Image.new("RGBA", (canvas_w, canvas_h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    scale = size / 100.0 * S

    def P(x, y):
        return (x * scale, (y + bob) * scale)

    def Rr(r):
        return r * scale

    LW = max(2, int(2.6 * scale))

    cx, cy = CX, CY
    body_cx, body_cy, body_rx, body_ry = BODY_CX, BODY_CY, BODY_RX, BODY_RY

    # ---- tail ----
    tp0 = (body_cx + body_rx * 0.55, body_cy + body_ry * 0.55)
    tp1 = (body_cx + body_rx * 1.45, body_cy + body_ry * 0.75)
    tp2 = (body_cx + body_rx * 1.55, body_cy - body_ry * 0.35)
    tp3 = (body_cx + body_rx * 1.00, body_cy - body_ry * 0.75)
    tail_pts = _bezier(tp0, tp1, tp2, tp3, n=28)
    r0, r1 = R * 0.22, R * 0.11
    n = len(tail_pts)
    for i, (x, y) in enumerate(tail_pts):
        t = i / (n - 1)
        rad = r0 * (1 - t) + r1 * t
        x0, y0 = P(x, y)
        rr = Rr(rad) + LW * 0.5
        d.ellipse([x0 - rr, y0 - rr, x0 + rr, y0 + rr], fill=BLACK)
    for i, (x, y) in enumerate(tail_pts):
        t = i / (n - 1)
        rad = r0 * (1 - t) + r1 * t
        x0, y0 = P(x, y)
        rr = Rr(rad)
        d.ellipse([x0 - rr, y0 - rr, x0 + rr, y0 + rr], fill=CREAM)
    tp_a0, tp_a1 = P(body_cx + body_rx * 1.05, body_cy - body_ry * 0.05), P(body_cx + body_rx * 1.45, body_cy + body_ry * 0.35)
    d.ellipse([tp_a0, tp_a1], fill=BLACK)
    tp_b0, tp_b1 = P(body_cx + body_rx * 0.65, body_cy + body_ry * 0.40), P(body_cx + body_rx * 1.05, body_cy + body_ry * 0.80)
    d.ellipse([tp_b0, tp_b1], fill=ORANGE)

    # ---- body ----
    bx0, by0 = P(body_cx - body_rx, body_cy - body_ry)
    bx1, by1 = P(body_cx + body_rx, body_cy + body_ry)
    d.ellipse([bx0, by0, bx1, by1], fill=CREAM, outline=BLACK, width=LW)
    px0, py0 = P(body_cx + body_rx * 0.10, body_cy - body_ry * 0.75)
    px1, py1 = P(body_cx + body_rx * 0.95, body_cy + body_ry * 0.15)
    d.ellipse([px0, py0, px1, py1], fill=ORANGE)
    px2, py2 = P(body_cx - body_rx * 0.95, body_cy + body_ry * 0.05)
    px3, py3 = P(body_cx - body_rx * 0.10, body_cy + body_ry * 0.95)
    d.ellipse([px2, py2, px3, py3], fill=BLACK)
    d.ellipse([bx0, by0, bx1, by1], outline=BLACK, width=LW)

    # ---- paws ----
    paw_y = body_cy + body_ry * 0.65
    paw_rx, paw_ry = R * 0.30, R * 0.24
    lx, ly = P(body_cx - R * 0.62, paw_y)
    rx_, ry_ = P(body_cx + R * 0.05, paw_y)
    lrx, lry = Rr(paw_rx), Rr(paw_ry)
    d.ellipse([lx - lrx, ly - lry, lx + lrx, ly + lry], fill=BLACK, outline=BLACK, width=LW)
    d.pieslice([lx - lrx, ly - lry, lx + lrx * 0.3, ly + lry], 90, 270, fill=CREAM)
    d.ellipse([lx - lrx, ly - lry, lx + lrx, ly + lry], outline=BLACK, width=LW)
    d.ellipse([rx_ - lrx, ry_ - lry, rx_ + lrx, ry_ + lry], fill=CREAM, outline=BLACK, width=LW)

    # ---- ears ----
    def poly(*pts):
        return [P(x, y) for x, y in pts]

    d.polygon(poly((cx - R * 1.10, cy - R * 0.30), (cx - R * 0.75, cy - R * 1.45), (cx - R * 0.20, cy - R * 0.45)),
              fill=CREAM, outline=BLACK, width=LW)
    d.polygon(poly((cx - R * 0.92, cy - R * 0.45), (cx - R * 0.75, cy - R * 1.13), (cx - R * 0.45, cy - R * 0.48)),
              fill=PINK)
    d.polygon(poly((cx + R * 1.10, cy - R * 0.30), (cx + R * 0.75, cy - R * 1.45), (cx + R * 0.20, cy - R * 0.45)),
              fill=BLACK, outline=BLACK, width=LW)
    d.polygon(poly((cx + R * 0.92, cy - R * 0.45), (cx + R * 0.75, cy - R * 1.13), (cx + R * 0.45, cy - R * 0.48)),
              fill=PINK)

    # ---- head ----
    hx0, hy0 = P(cx - R, cy - R)
    hx1, hy1 = P(cx + R, cy + R)
    d.ellipse([hx0, hy0, hx1, hy1], fill=CREAM, outline=BLACK, width=LW)
    hpx0, hpy0 = P(cx - R * 0.92, cy - R * 0.95)
    hpx1, hpy1 = P(cx - R * 0.02, cy - R * 0.02)
    d.ellipse([hpx0, hpy0, hpx1, hpy1], fill=ORANGE)
    hpx2, hpy2 = P(cx + R * 0.14, cy - R * 0.52)
    hpx3, hpy3 = P(cx + R * 0.95, cy + R * 0.16)
    d.ellipse([hpx2, hpy2, hpx3, hpy3], fill=BLACK)
    d.ellipse([hx0, hy0, hx1, hy1], outline=BLACK, width=LW)

    # ---- eyes ----
    eye_r = R * 0.165
    ex, ey = R * 0.50, R * 0.12
    lex, ley = cx - ex, cy + ey
    rex, rey = cx + ex, cy + ey

    # small light "eye socket" behind each eye so eyes stay visible even when
    # they sit on top of the black fur patch
    socket_r = eye_r * 1.55
    for exc, eyc in [(lex, ley), (rex, rey)]:
        sx, sy = P(exc, eyc)
        sr = Rr(socket_r)
        d.ellipse([sx - sr, sy - sr, sx + sr, sy + sr], fill=CREAM)

    if eye_mode == "blink":
        lx0, ly0 = P(lex - eye_r, ley)
        lx1, ly1 = P(lex + eye_r, ley)
        rx0, ry0 = P(rex - eye_r, rey)
        rx1, ry1 = P(rex + eye_r, rey)
        d.line([lx0, ly0, lx1, ly1], fill=BLACK, width=max(2, int(R * 0.05 * scale)))
        d.line([rx0, ry0, rx1, ry1], fill=BLACK, width=max(2, int(R * 0.05 * scale)))
    elif eye_mode == "happy":
        for exc, eyc in [(lex, ley), (rex, rey)]:
            x0, y0 = P(exc - eye_r, eyc + eye_r * 0.3)
            x1, y1 = P(exc + eye_r, eyc - eye_r * 0.9)
            d.arc([x0, y1, x1, y0], start=200, end=340, fill=BLACK, width=max(2, int(R * 0.05 * scale)))
    else:  # open
        lex0, ley0 = P(lex, ley)
        rex0, rey0 = P(rex, rey)
        errp = Rr(eye_r)
        d.ellipse([lex0 - errp, ley0 - errp, lex0 + errp, ley0 + errp], fill=BLACK)
        d.ellipse([rex0 - errp, rey0 - errp, rex0 + errp, rey0 + errp], fill=BLACK)
        hl = Rr(R * 0.055)
        d.ellipse([lex0 - errp * 0.35 - hl, ley0 - errp * 0.4 - hl, lex0 - errp * 0.35 + hl, ley0 - errp * 0.4 + hl], fill=(255, 255, 255, 235))
        d.ellipse([rex0 - errp * 0.35 - hl, rey0 - errp * 0.4 - hl, rex0 - errp * 0.35 + hl, rey0 - errp * 0.4 + hl], fill=(255, 255, 255, 235))

    # ---- cheeks ----
    c0 = P(cx - R * 0.88, cy + R * 0.45)
    c1 = P(cx - R * 0.45, cy + R * 0.75)
    d.ellipse([c0, c1], fill=PINK_CHEEK)
    c2 = P(cx + R * 0.45, cy + R * 0.45)
    c3 = P(cx + R * 0.88, cy + R * 0.75)
    d.ellipse([c2, c3], fill=PINK_CHEEK)

    # ---- nose ----
    d.polygon(poly((cx - R * 0.08, cy + R * 0.48), (cx + R * 0.08, cy + R * 0.48), (cx, cy + R * 0.60)), fill=PINK)

    # ---- mouth ----
    if mouth_mode == "open":
        ox0, oy0 = P(cx - R * 0.16, cy + R * 0.50)
        ox1, oy1 = P(cx + R * 0.16, cy + R * 0.78)
        d.ellipse([ox0, oy0, ox1, oy1], fill=(120, 40, 55, 255), outline=BLACK, width=max(2, int(R * 0.03 * scale)))
    else:
        mlx0, mly0 = P(cx - R * 0.32, cy + R * 0.44)
        mlx1, mly1 = P(cx - R * 0.02, cy + R * 0.62)
        mlc = P(cx - R * 0.17, cy + R * 0.72)
        d.line([mlx0, mlc, mlx1], fill=BLACK, width=max(2, int(R * 0.045 * scale)), joint="curve")
        mrx0, mry0 = P(cx + R * 0.02, cy + R * 0.62)
        mrx1, mry1 = P(cx + R * 0.32, cy + R * 0.44)
        mrc = P(cx + R * 0.17, cy + R * 0.72)
        d.line([mrx0, mrc, mrx1], fill=BLACK, width=max(2, int(R * 0.045 * scale)), joint="curve")

    # ---- whiskers ----
    for yoff in [-0.05, 0.05, 0.15]:
        y = cy + R * 0.25 + R * yoff
        a = P(cx - R * 1.05, y)
        b = P(cx - R * 1.85, y - R * 0.06)
        d.line([a, b], fill=BLACK, width=max(1, int(0.7 * scale)))
        c = P(cx + R * 1.05, y)
        e = P(cx + R * 1.85, y - R * 0.06)
        d.line([c, e], fill=BLACK, width=max(1, int(0.7 * scale)))

    img = img.resize((int(canvas_w / S), int(canvas_h / S)), Image.LANCZOS)
    return img
