#!/usr/bin/env python3
"""
Generates the default 'calico_kitten' sprite set used as sample/demo art.

Run once to (re)create sprites/calico_kitten/**. Safe to re-run; it overwrites
existing files in that folder only. Your own custom pet folders (e.g.
sprites/my_pet/) are never touched by this script.

Usage:
    python tools/generate_sprites.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tools.kitten_art import draw_kitten  # noqa: E402

OUT_ROOT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "sprites", "calico_kitten")


def save(img, *path_parts):
    path = os.path.join(OUT_ROOT, *path_parts)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.save(path)
    print("wrote", os.path.relpath(path, OUT_ROOT))


def main():
    size = 300  # base render size in px (before the app's own SPRITE_SCALE is applied)

    # idle: gentle blink cycle
    save(draw_kitten(eye_mode="open", mouth_mode="smile", size=size), "idle", "frame_00.png")
    save(draw_kitten(eye_mode="blink", mouth_mode="smile", size=size), "idle", "frame_01.png")

    # walk: reuse the blink cycle so the pet still feels alive while moving
    save(draw_kitten(eye_mode="open", mouth_mode="smile", bob=-1.2, size=size), "walk", "frame_00.png")
    save(draw_kitten(eye_mode="open", mouth_mode="smile", bob=1.2, size=size), "walk", "frame_01.png")

    # sleep: closed eyes, single calm frame
    save(draw_kitten(eye_mode="blink", mouth_mode="smile", size=size), "sleep", "frame_00.png")

    # play: excited open-mouth frames
    save(draw_kitten(eye_mode="open", mouth_mode="open", size=size), "play", "frame_00.png")
    save(draw_kitten(eye_mode="happy", mouth_mode="open", size=size), "play", "frame_01.png")

    # happy: curved joyful eyes
    save(draw_kitten(eye_mode="happy", mouth_mode="open", size=size), "happy", "frame_00.png")
    save(draw_kitten(eye_mode="happy", mouth_mode="smile", size=size), "happy", "frame_01.png")

    # drag: a little "surprised" look while being picked up
    save(draw_kitten(eye_mode="open", mouth_mode="open", size=size), "drag", "frame_00.png")

    print("\nDone. Sprites written to:", OUT_ROOT)


if __name__ == "__main__":
    main()
