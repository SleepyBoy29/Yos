"""
Central configuration for the desktop pet.
Tweak these values to change timing, size, and behavior without touching app logic.
"""
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SPRITES_ROOT = os.path.join(BASE_DIR, "sprites")

# Which subfolder of sprites/ to load. Each pet "skin" lives in its own folder,
# e.g. sprites/calico_kitten/, sprites/my_custom_pet/, etc.
PET_NAME = os.environ.get("PET_NAME", "calico_kitten")

# --- Animation timing ---
FRAME_MS = 180              # milliseconds between animation frames
WALK_TICK_MS = 30           # how often the pet's position updates while walking
WALK_SPEED_PX = 3           # pixels moved per walk tick

# --- Autonomous behavior timing (how "alive" the pet feels) ---
AUTONOMY_MIN_S = 6.0        # minimum idle seconds before a random activity triggers
AUTONOMY_MAX_S = 14.0       # maximum idle seconds before a random activity triggers
INTERACTION_COOLDOWN_S = 2.5  # pause autonomous behavior this long after user interaction

SLEEP_DURATION_S = (4.0, 7.5)
PLAY_DURATION_S = 1.6
HAPPY_DURATION_S = 1.4

# --- Speech bubble / status icon ---
BUBBLE_DURATION_MS = 5000
STATUS_DURATION_MS = 1600
BUBBLE_FONT = ("Segoe UI", 10)
BUBBLE_BG = "#ffffff"
BUBBLE_FG = "#222222"
BUBBLE_BORDER = "#e2c94a"

STATUS_FONT = ("Segoe UI Emoji", 16)

# --- Window / rendering ---
SPRITE_SCALE = 1.6          # overall size multiplier applied to loaded sprite images
ALWAYS_ON_TOP = True
# Colorkey used for transparency. Reliably works on Windows via -transparentcolor.
# On Linux this is best-effort (depends on window manager / compositor); see README.
TRANSPARENT_KEY = "#ff00fe"
STARTUP_CORNER_MARGIN = 40  # px from the screen edge where the pet first appears

# --- Random tip sentences shown when the pet is clicked ---
TIPS = [
    "Hi there! Click and drag me anywhere on your screen.",
    "Tip: I'll wander around on my own if you leave me alone for a bit.",
    "Meow! Just keeping you company while you work.",
    "Tip: Right-click me for options, including Quit.",
    "Remember to take a short break every once in a while!",
    "I like to nap, play, and zoom around when nobody's watching.",
    "You can swap my look anytime — just replace the sprite images.",
    "Tip: Drag me to the edge of the screen and I'll stay put.",
    "Great job getting things done today!",
    "Tip: Double-click me for a little surprise.",
]
