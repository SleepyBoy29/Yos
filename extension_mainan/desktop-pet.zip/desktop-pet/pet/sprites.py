"""
Loads per-state sprite folders (idle, walk, sleep, play, happy, drag) and hands out
animation frames. Each state folder can hold one or many images; multiple images
are treated as animation frames and played back in filename order.

Folder layout expected under sprites/<pet_name>/:
    idle/    frame_00.png, frame_01.png, ...
    walk/    frame_00.png, frame_01.png, ...
    sleep/   frame_00.png, ...
    play/    frame_00.png, ...
    happy/   frame_00.png, ...
    drag/    frame_00.png, ...   (optional; falls back to idle if missing)

Only PNG/GIF/BMP files are read. Missing or empty state folders fall back to the
idle animation so the app never crashes because of missing art.
"""
import os
from PIL import Image

VALID_EXT = (".png", ".gif", ".bmp", ".jpg", ".jpeg")


class SpriteSet:
    """Holds the animation frames for a single state (e.g. 'walk')."""

    def __init__(self, frames):
        self.frames = frames  # list of PIL.Image.Image (RGBA)

    def __len__(self):
        return len(self.frames)

    def __bool__(self):
        return len(self.frames) > 0

    def frame(self, index):
        if not self.frames:
            return None
        return self.frames[index % len(self.frames)]


class SpriteManager:
    STATES = ["idle", "walk", "sleep", "play", "happy", "drag"]

    def __init__(self, sprite_dir, scale=1.0):
        self.sprite_dir = sprite_dir
        self.scale = scale
        self.sets = {}
        self._load_all()

    def _load_folder(self, folder):
        if not os.path.isdir(folder):
            return []
        files = sorted(f for f in os.listdir(folder) if f.lower().endswith(VALID_EXT))
        frames = []
        for fname in files:
            path = os.path.join(folder, fname)
            try:
                img = Image.open(path).convert("RGBA")
                if self.scale != 1.0:
                    w, h = img.size
                    new_w = max(1, int(w * self.scale))
                    new_h = max(1, int(h * self.scale))
                    img = img.resize((new_w, new_h), Image.LANCZOS)
                frames.append(img)
            except Exception as e:  # noqa: BLE001 - want to keep going regardless
                print(f"[SpriteManager] Failed to load '{path}': {e}")
        return frames

    def _load_all(self):
        for state in self.STATES:
            folder = os.path.join(self.sprite_dir, state)
            self.sets[state] = SpriteSet(self._load_folder(folder))

        # Anything empty falls back to idle so the app keeps working even with
        # partial custom sprite sets.
        idle_set = self.sets.get("idle")
        for state in self.STATES:
            if state == "idle":
                continue
            if not self.sets[state]:
                if idle_set:
                    print(f"[SpriteManager] No sprites in '{state}/' — using idle sprites instead.")
                self.sets[state] = idle_set

        if not self.sets.get("idle"):
            raise FileNotFoundError(
                f"No sprite frames found in '{os.path.join(self.sprite_dir, 'idle')}'. "
                "Add at least one .png there before running the pet."
            )

    def get(self, state):
        return self.sets.get(state) or self.sets["idle"]

    def max_size(self):
        w = h = 0
        for s in self.sets.values():
            for f in s.frames:
                w = max(w, f.width)
                h = max(h, f.height)
        return (w or 100, h or 100)
