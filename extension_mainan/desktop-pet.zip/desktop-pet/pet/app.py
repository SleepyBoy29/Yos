"""
Desktop Pet — a small always-on-top companion that idles, wanders, naps, plays,
and reacts to clicks and dragging. Works on Windows and Linux (Tkinter + Pillow).

Run it via ../main.py, not this file directly.
"""
import os
import random
import sys
import time
import tkinter as tk
from tkinter import Menu

from PIL import Image, ImageOps, ImageTk

from . import config
from .sprites import SpriteManager

IS_WINDOWS = sys.platform.startswith("win")


class Bubble(tk.Toplevel):
    """A small borderless speech-bubble window for tip text."""

    def __init__(self, master):
        super().__init__(master)
        self.overrideredirect(True)
        self.attributes("-topmost", True)
        try:
            self.attributes("-alpha", 0.97)
        except tk.TclError:
            pass
        self.withdraw()

        self.frame = tk.Frame(
            self, bg=config.BUBBLE_BG, highlightbackground=config.BUBBLE_BORDER,
            highlightthickness=2, bd=0,
        )
        self.frame.pack(fill="both", expand=True)
        self.label = tk.Label(
            self.frame, text="", justify="left", wraplength=220,
            bg=config.BUBBLE_BG, fg=config.BUBBLE_FG, font=config.BUBBLE_FONT,
            padx=10, pady=8,
        )
        self.label.pack()
        self._hide_job = None

    def show(self, text, x, y, duration_ms):
        self.label.config(text=text)
        self.update_idletasks()
        w = self.winfo_reqwidth()
        h = self.winfo_reqheight()
        self.geometry(f"{w}x{h}+{int(x - w / 2)}+{int(y - h)}")
        self.deiconify()
        self.lift()
        if self._hide_job:
            self.after_cancel(self._hide_job)
        self._hide_job = self.after(duration_ms, self.hide)

    def hide(self):
        self._hide_job = None
        self.withdraw()


class PetApp:
    STATE_IDLE = "idle"
    STATE_WALK = "walk"
    STATE_SLEEP = "sleep"
    STATE_PLAY = "play"
    STATE_HAPPY = "happy"
    STATE_DRAG = "drag"

    def __init__(self, pet_name=None, sprite_scale=None):
        pet_name = pet_name or config.PET_NAME
        sprite_scale = sprite_scale if sprite_scale is not None else config.SPRITE_SCALE

        sprite_dir = os.path.join(config.SPRITES_ROOT, pet_name)
        self.sprites = SpriteManager(sprite_dir, scale=sprite_scale)
        self.max_w, self.max_h = self.sprites.max_size()

        self.root = tk.Tk()
        self.root.title("Desktop Pet")
        self.root.overrideredirect(True)
        if config.ALWAYS_ON_TOP:
            self.root.attributes("-topmost", True)
        self._apply_transparency()

        self.canvas = tk.Canvas(
            self.root, width=self.max_w, height=self.max_h,
            highlightthickness=0, bd=0, bg=config.TRANSPARENT_KEY,
        )
        self.canvas.pack()

        self.bubble = Bubble(self.root)

        # ---- runtime state ----
        self.state = self.STATE_IDLE
        self.frame_index = 0
        self.facing_left = False
        self.tk_image = None
        self.image_item = None
        self.status_item = None
        self.status_hide_job = None

        self.is_dragging = False
        self.drag_moved = False
        self.drag_offset = (0, 0)
        self.drag_start = (0, 0)
        self.last_interaction = 0.0

        self._walk_job = None
        self._activity_job = None
        self._state_end_job = None
        self._quitting = False

        self._place_initial_position()
        self._build_context_menu()
        self._bind_events()

        self._animate_frame()
        self._schedule_autonomy()

    # ------------------------------------------------------------------ #
    # Setup helpers
    # ------------------------------------------------------------------ #
    def _apply_transparency(self):
        """Best-effort transparency: reliable on Windows, best-effort on Linux."""
        try:
            self.root.wm_attributes("-transparentcolor", config.TRANSPARENT_KEY)
        except tk.TclError:
            # Not supported (typically Linux/macOS). Try whole-window alpha as a
            # softer fallback so the pet isn't a jarring solid rectangle; the
            # colorkey background will still show as a solid color on these
            # platforms unless the window manager supports transparentcolor too.
            try:
                self.root.wait_visibility(self.root)
                self.root.wm_attributes("-alpha", 1.0)
            except tk.TclError:
                pass

    def _place_initial_position(self):
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        x = sw - self.max_w - config.STARTUP_CORNER_MARGIN
        y = sh - self.max_h - config.STARTUP_CORNER_MARGIN
        self.root.geometry(f"{self.max_w}x{self.max_h}+{x}+{y}")

    def _build_context_menu(self):
        self.menu = Menu(self.root, tearoff=0)
        self.menu.add_command(label="Show a tip", command=self._show_random_tip)
        self.menu.add_separator()
        self.menu.add_command(label="Quit", command=self.quit)

    def _bind_events(self):
        self.canvas.bind("<ButtonPress-1>", self._on_press)
        self.canvas.bind("<B1-Motion>", self._on_motion)
        self.canvas.bind("<ButtonRelease-1>", self._on_release)
        self.canvas.bind("<Button-3>", self._on_right_click)
        self.root.bind("<Escape>", lambda e: None)  # reserved, no-op by default

    # ------------------------------------------------------------------ #
    # Rendering
    # ------------------------------------------------------------------ #
    def _current_sprite_set(self):
        return self.sprites.get(self.state)

    def _animate_frame(self):
        if self._quitting:
            return
        sprite_set = self._current_sprite_set()
        img = sprite_set.frame(self.frame_index)
        self.frame_index += 1

        if img is not None:
            if self.facing_left:
                img = ImageOps.mirror(img)
            self.tk_image = ImageTk.PhotoImage(img)
            if self.image_item is None:
                self.image_item = self.canvas.create_image(
                    self.max_w // 2, self.max_h // 2, image=self.tk_image
                )
            else:
                self.canvas.itemconfig(self.image_item, image=self.tk_image)
                self.canvas.coords(self.image_item, self.max_w // 2, self.max_h // 2)
            self.canvas.tag_lower(self.image_item)
            if self.status_item:
                self.canvas.tag_raise(self.status_item)

        self.root.after(config.FRAME_MS, self._animate_frame)

    def _show_status(self, emoji, duration_ms=None):
        if self.status_item:
            self.canvas.delete(self.status_item)
        self.status_item = self.canvas.create_text(
            self.max_w // 2, max(12, self.max_h * 0.08),
            text=emoji, font=config.STATUS_FONT, fill="#000000",
        )
        if self.status_hide_job:
            self.root.after_cancel(self.status_hide_job)
            self.status_hide_job = None
        if duration_ms:
            self.status_hide_job = self.root.after(duration_ms, self._hide_status)

    def _hide_status(self):
        self.status_hide_job = None
        if self.status_item:
            self.canvas.delete(self.status_item)
            self.status_item = None

    # ------------------------------------------------------------------ #
    # Interaction: drag & click
    # ------------------------------------------------------------------ #
    def _on_press(self, event):
        self.is_dragging = True
        self.drag_moved = False
        self.last_interaction = time.time()
        wx = self.root.winfo_x()
        wy = self.root.winfo_y()
        self.drag_offset = (event.x_root - wx, event.y_root - wy)
        self.drag_start = (event.x_root, event.y_root)
        # Interrupting whatever the pet was doing: cancel any in-flight timers
        # so we don't end up with two autonomy loops racing each other, then
        # re-arm a single fresh one below via _on_release / _enter_state.
        self._cancel_walk()
        self._cancel_state_end()
        self.state = self.STATE_DRAG
        self.frame_index = 0

    def _on_motion(self, event):
        if not self.is_dragging:
            return
        dx = event.x_root - self.drag_start[0]
        dy = event.y_root - self.drag_start[1]
        if abs(dx) > 4 or abs(dy) > 4:
            self.drag_moved = True
        new_x = event.x_root - self.drag_offset[0]
        new_y = event.y_root - self.drag_offset[1]
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        new_x = max(0, min(sw - self.max_w, new_x))
        new_y = max(0, min(sh - self.max_h, new_y))
        self.root.geometry(f"+{new_x}+{new_y}")

    def _on_release(self, event):
        if not self.is_dragging:
            return
        self.is_dragging = False
        self.last_interaction = time.time()
        if self.drag_moved:
            self._enter_state(self.STATE_HAPPY, duration_s=config.HAPPY_DURATION_S,
                               status="\u2728", on_done=self._schedule_autonomy)
        else:
            self._show_random_tip()
            self.state = self.STATE_IDLE
            self.frame_index = 0
            self._schedule_autonomy()

    def _on_right_click(self, event):
        try:
            self.menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.menu.grab_release()

    def _show_random_tip(self):
        tip = random.choice(config.TIPS)
        x = self.root.winfo_x() + self.max_w // 2
        y = self.root.winfo_y()
        self.bubble.show(tip, x, y, config.BUBBLE_DURATION_MS)

    # ------------------------------------------------------------------ #
    # Autonomous behavior
    # ------------------------------------------------------------------ #
    def _schedule_autonomy(self):
        if self._quitting:
            return
        if self._activity_job:
            self.root.after_cancel(self._activity_job)
            self._activity_job = None
        wait_s = random.uniform(config.AUTONOMY_MIN_S, config.AUTONOMY_MAX_S)
        self._activity_job = self.root.after(int(wait_s * 1000), self._maybe_run_activity)

    def _maybe_run_activity(self):
        if self._quitting:
            return
        if self.is_dragging or (time.time() - self.last_interaction) < config.INTERACTION_COOLDOWN_S:
            self._schedule_autonomy()
            return
        self._run_random_activity()

    def _run_random_activity(self):
        choice = random.choice(["walk", "walk", "play", "sleep", "happy"])
        if choice == "walk":
            self._start_walk()
        elif choice == "play":
            self._enter_state(self.STATE_PLAY, duration_s=config.PLAY_DURATION_S,
                               status="\U0001F389", on_done=self._schedule_autonomy)
        elif choice == "sleep":
            dur = random.uniform(*config.SLEEP_DURATION_S)
            self._enter_state(self.STATE_SLEEP, duration_s=dur,
                               status="\U0001F4A4", on_done=self._schedule_autonomy)
        elif choice == "happy":
            self._enter_state(self.STATE_HAPPY, duration_s=config.HAPPY_DURATION_S,
                               status="\u2764\uFE0F", on_done=self._schedule_autonomy)
        else:
            self._schedule_autonomy()

    def _enter_state(self, state, duration_s=None, status=None, on_done=None):
        self.state = state
        self.frame_index = 0
        if status:
            self._show_status(status, duration_ms=int((duration_s or 1.5) * 1000))
        self._cancel_state_end()
        if duration_s:
            self._state_end_job = self.root.after(
                int(duration_s * 1000), lambda: self._end_state(on_done)
            )

    def _cancel_state_end(self):
        if self._state_end_job:
            self.root.after_cancel(self._state_end_job)
            self._state_end_job = None

    def _end_state(self, on_done):
        self._state_end_job = None
        self.state = self.STATE_IDLE
        self.frame_index = 0
        if on_done:
            on_done()
        else:
            self._schedule_autonomy()

    # ------------------------------------------------------------------ #
    # Walking
    # ------------------------------------------------------------------ #
    def _start_walk(self):
        sw = self.root.winfo_screenwidth()
        margin = 10
        current_x = self.root.winfo_x()
        target_x = random.randint(margin, max(margin, sw - self.max_w - margin))
        self.facing_left = target_x < current_x
        self.state = self.STATE_WALK
        self.frame_index = 0
        self._walk_step(target_x)

    def _cancel_walk(self):
        if self._walk_job:
            self.root.after_cancel(self._walk_job)
            self._walk_job = None

    def _walk_step(self, target_x):
        if self._quitting or self.is_dragging:
            return
        current_x = self.root.winfo_x()
        y = self.root.winfo_y()
        step = config.WALK_SPEED_PX
        if current_x < target_x:
            new_x = min(target_x, current_x + step)
        else:
            new_x = max(target_x, current_x - step)
        self.root.geometry(f"+{new_x}+{y}")

        if new_x == target_x:
            self._walk_job = None
            self.state = self.STATE_IDLE
            self.frame_index = 0
            self._schedule_autonomy()
        else:
            self._walk_job = self.root.after(config.WALK_TICK_MS, lambda: self._walk_step(target_x))

    # ------------------------------------------------------------------ #
    # Lifecycle
    # ------------------------------------------------------------------ #
    def run(self):
        self.root.mainloop()

    def quit(self):
        self._quitting = True
        self._cancel_walk()
        self._cancel_state_end()
        if self._activity_job:
            self.root.after_cancel(self._activity_job)
        self.root.destroy()
