#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

PYTHON=python3

if ! $PYTHON -c "import tkinter" >/dev/null 2>&1; then
    echo "tkinter is not available for $PYTHON."
    echo "On Debian/Ubuntu:  sudo apt install python3-tk"
    echo "On Fedora:         sudo dnf install python3-tkinter"
    echo "On Arch:           sudo pacman -S tk"
    exit 1
fi

if [ ! -d ".venv" ]; then
    echo "Creating virtual environment..."
    $PYTHON -m venv .venv
fi

source .venv/bin/activate
if ! python -c "import PIL" >/dev/null 2>&1; then
    echo "Installing dependencies..."
    pip install -r requirements.txt
fi

python main.py "$@"
