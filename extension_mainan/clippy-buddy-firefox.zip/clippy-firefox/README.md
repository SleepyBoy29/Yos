# Clippy Buddy — for Mozilla Firefox

A floating animated paperclip character (inspired by the classic Windows Clippy).

## Features
- Idle bounce animation when just sitting there
- **Drag & drop** — click and hold, then move it anywhere on the page
- **Click** it (without dragging) to get a random tip in English
- **Autonomous behavior** — when you leave it alone for a while, it will randomly:
  - 🚶 Walk left/right across the screen (faces the direction it's moving)
  - 🎉 Play (a little spin/hop)
  - 💤 Sleep (eyes close, "Zzz" appears)
  - ❤️ Show happiness (jumps a few times)
- **Health reminders** — Clippy looks out for you while you're glued to the screen:
  - 🚶 Every **30 minutes**: a nudge to stand up, stretch, and move around
  - 💧 Every **45 minutes**: a nudge to drink some water

## Install on Firefox

### Temporary install (for trying it out / development)
1. Unzip this folder.
2. Open `about:debugging#/runtime/this-firefox` in the address bar.
3. Click **Load Temporary Add-on…**.
4. Select the `manifest.json` file inside the unzipped `clippy-firefox` folder.
5. Open any website — Clippy will appear in the bottom-right corner!

Note: temporary add-ons are removed when Firefox restarts, so you'll need to reload it each session.

### Permanent install (signed by you / for personal long-term use)
Firefox requires extensions to be signed by Mozilla to stay installed permanently in regular Firefox. For personal use without going through the Add-ons store, use **Firefox Developer Edition** or **Firefox Nightly**, and either:
- Set `xpinstall.signatures.required` to `false` in `about:config`, then install the zipped extension directly, or
- Submit it for self-distribution signing via https://addons.mozilla.org/developers/ (free, works for unlisted/private extensions too).

## Customize
- Edit the `TIPS` array in `content.js` to change what it says when clicked.
- Edit `STAND_TIPS` / `WATER_TIPS` to change the reminder messages.
- Change `STAND_INTERVAL_MS` / `WATER_INTERVAL_MS` at the top of `content.js` to adjust how often the health reminders fire (values are in milliseconds).
- Adjust timing in `activityLoop()` (`rand(6000, 13000)`) to make the idle animations more or less active.
- Edit `content.css` to change size, colors, or animation speed.

## Note on the reminder intervals
30 minutes for standing/movement and 45 minutes for water are reasonable, commonly used defaults for people at a desk — but they're not medical advice. Feel free to tune `STAND_INTERVAL_MS` and `WATER_INTERVAL_MS` to whatever cadence works best for you.
