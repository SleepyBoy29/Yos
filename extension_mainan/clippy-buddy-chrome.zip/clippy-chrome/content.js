(function () {
  "use strict";

  if (document.getElementById("clippy-buddy-root")) return;

  var TIPS = [
    "Hi there! Looks like you're browsing. Need a hand?",
    "Tip: Press Ctrl+T (or Cmd+T on Mac) to open a new tab.",
    "You can drag me anywhere on the screen!",
    "Tip: Ctrl+Shift+T reopens the last tab you closed.",
    "Remember to save your work often!",
    "Tip: You can zoom a page with Ctrl and + or -.",
    "Feeling stuck? Take a short break and stretch a little.",
    "Tip: Ctrl+F lets you search for text on this page.",
    "I'm just a friendly paperclip, here to keep you company.",
    "Tip: Bookmark this page with Ctrl+D if you want to find it again.",
    "Great job getting things done today!",
    "Tip: Middle-click a link to open it in a new tab.",
    "I like to wander around when you're not looking!"
  ];

  // ---- Health reminders ----
  // Sitting too long and forgetting to hydrate are two of the most common
  // side effects of long computer sessions, so Clippy nudges you gently.
  var STAND_INTERVAL_MS = 30 * 60 * 1000; // stand up / move every 30 minutes
  var WATER_INTERVAL_MS = 45 * 60 * 1000; // drink water every 45 minutes

  var STAND_TIPS = [
    "You've been sitting a while \u2014 stand up and stretch for a minute! \uD83D\uDEB6",
    "Time for a quick break! Get up, walk around, and shake out your legs.",
    "Your body will thank you \u2014 stand up, roll your shoulders, and take a few steps.",
    "Quick reminder: sitting too long isn't great for you. Stand and stretch a bit!",
    "Break time! A short walk now helps your focus for the next stretch of work."
  ];

  var WATER_TIPS = [
    "Hydration check! \uD83D\uDCA7 Grab a glass of water.",
    "Time to drink some water \u2014 your brain works better when you're hydrated!",
    "Friendly reminder: have a sip of water. Staying hydrated helps you focus.",
    "Don't forget to drink water! A little now keeps you feeling sharp.",
    "Water break! \uD83D\uDCA7 Keep that hydration up while you work."
  ];

  function rand(min, max) { return Math.random() * (max - min) + min; }
  function randInt(min, max) { return Math.floor(rand(min, max + 1)); }
  function randomFrom(arr) { return arr[randInt(0, arr.length - 1)]; }
  function randomTip() { return randomFrom(TIPS); }
  function wait(ms) { return new Promise(function (res) { setTimeout(res, ms); }); }

  // ---- Build DOM ----
  var root = document.createElement("div");
  root.id = "clippy-buddy-root";

  var status = document.createElement("div");
  status.id = "clippy-buddy-status";

  var bubble = document.createElement("div");
  bubble.id = "clippy-buddy-bubble";

  var bubbleText = document.createElement("span");
  bubbleText.id = "clippy-buddy-bubble-text";
  bubble.appendChild(bubbleText);

  var closeBtn = document.createElement("div");
  closeBtn.id = "clippy-buddy-close";
  closeBtn.textContent = "\u00D7";
  bubble.appendChild(closeBtn);

  var character = document.createElement("div");
  character.id = "clippy-buddy-character";
  character.setAttribute("role", "button");
  character.setAttribute("aria-label", "Clippy Buddy assistant, draggable");

  var flip = document.createElement("div");
  flip.id = "clippy-buddy-flip";
  flip.innerHTML =
    '<svg viewBox="0 0 100 120" xmlns="http://www.w3.org/2000/svg" width="100%" height="100%">' +
      '<path d="M55 8 C75 8 82 25 82 40 L82 85 C82 102 68 112 52 112 C36 112 24 102 24 86 L24 38" ' +
        'fill="none" stroke="#3a3a3a" stroke-width="7" stroke-linecap="round"/>' +
      '<path d="M62 22 C72 22 76 32 76 41 L76 80 C76 90 68 96 58 96 C49 96 42 90 42 80 L42 36" ' +
        'fill="none" stroke="#3a3a3a" stroke-width="6" stroke-linecap="round"/>' +
      '<circle id="clippy-buddy-eye-left" cx="47" cy="42" r="4.2" fill="#222"/>' +
      '<circle id="clippy-buddy-eye-right" cx="63" cy="42" r="4.2" fill="#222"/>' +
      '<path d="M46 56 Q55 63 64 56" fill="none" stroke="#222" stroke-width="3" stroke-linecap="round"/>' +
      '<ellipse cx="41" cy="47" rx="3" ry="1.6" fill="#ff9fb0" opacity="0.7"/>' +
      '<ellipse cx="69" cy="47" rx="3" ry="1.6" fill="#ff9fb0" opacity="0.7"/>' +
    '</svg>';

  character.appendChild(flip);
  root.appendChild(status);
  root.appendChild(bubble);
  root.appendChild(character);
  document.documentElement.appendChild(root);

  // ---- Initial position (bottom-right corner) ----
  function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }

  function initPosition() {
    var w = root.offsetWidth || 72;
    var h = root.offsetHeight || 84;
    var left = window.innerWidth - w - 24;
    var top = window.innerHeight - h - 24;
    root.style.left = clamp(left, 0, window.innerWidth - w) + "px";
    root.style.top = clamp(top, 0, window.innerHeight - h) + "px";
  }
  initPosition();

  window.addEventListener("resize", function () {
    var rect = root.getBoundingClientRect();
    root.style.left = clamp(rect.left, 0, window.innerWidth - rect.width) + "px";
    root.style.top = clamp(rect.top, 0, window.innerHeight - rect.height) + "px";
  });

  // ---- Speech bubble (click tips + reminders) ----
  var hideTimer = null;
  function showBubble(text, holdMs) {
    bubbleText.textContent = text;
    bubble.classList.add("visible");
    if (hideTimer) clearTimeout(hideTimer);
    hideTimer = setTimeout(function () { bubble.classList.remove("visible"); }, holdMs || 5000);
  }

  closeBtn.addEventListener("pointerdown", function (e) { e.stopPropagation(); });
  closeBtn.addEventListener("click", function (e) {
    e.stopPropagation();
    bubble.classList.remove("visible");
    if (hideTimer) clearTimeout(hideTimer);
  });

  // ---- Status emoji (ambient activities) ----
  var statusTimer = null;
  function showStatus(emoji, duration) {
    status.textContent = emoji;
    status.classList.add("visible");
    if (statusTimer) clearTimeout(statusTimer);
    if (duration) {
      statusTimer = setTimeout(function () { status.classList.remove("visible"); }, duration);
    }
  }
  function hideStatus() {
    status.classList.remove("visible");
  }

  // ---- Drag & drop ----
  var isDragging = false;
  var dragMoved = false;
  var offsetX = 0, offsetY = 0, startPX = 0, startPY = 0;
  var lastInteraction = 0;

  character.addEventListener("pointerdown", function (e) {
    isDragging = true;
    dragMoved = false;
    lastInteraction = Date.now();
    var rect = root.getBoundingClientRect();
    offsetX = e.clientX - rect.left;
    offsetY = e.clientY - rect.top;
    startPX = e.clientX;
    startPY = e.clientY;
    root.style.transition = "none";
    character.classList.add("clippy-dragging");
    character.classList.remove("clippy-state-walking", "clippy-state-sleeping", "clippy-state-playing", "clippy-state-happy");
    hideStatus();
    try { character.setPointerCapture(e.pointerId); } catch (err) {}
  });

  character.addEventListener("pointermove", function (e) {
    if (!isDragging) return;
    var dx = e.clientX - startPX, dy = e.clientY - startPY;
    if (Math.abs(dx) > 4 || Math.abs(dy) > 4) dragMoved = true;
    var rect = root.getBoundingClientRect();
    var newLeft = clamp(e.clientX - offsetX, 0, window.innerWidth - rect.width);
    var newTop = clamp(e.clientY - offsetY, 0, window.innerHeight - rect.height);
    root.style.left = newLeft + "px";
    root.style.top = newTop + "px";
  });

  function endDrag(e) {
    if (!isDragging) return;
    isDragging = false;
    character.classList.remove("clippy-dragging");
    lastInteraction = Date.now();
    root.style.transition = "";

    if (!dragMoved) {
      // treat as a click
      character.classList.remove("clippy-clicked");
      void character.offsetWidth;
      character.classList.add("clippy-clicked");
      showBubble(randomTip());
    } else {
      // landed after being dragged
      character.classList.add("clippy-state-happy");
      showStatus("\u2728", 1200);
      setTimeout(function () { character.classList.remove("clippy-state-happy"); }, 1400);
    }
  }

  character.addEventListener("pointerup", endDrag);
  character.addEventListener("pointercancel", endDrag);

  // ---- Autonomous activities ----
  function performWalk() {
    return new Promise(function (resolve) {
      var rect = root.getBoundingClientRect();
      var margin = 10;
      var maxLeft = window.innerWidth - rect.width - margin;
      var targetLeft = rand(margin, Math.max(margin, maxLeft));
      var distance = Math.abs(targetLeft - rect.left);
      var direction = targetLeft < rect.left ? -1 : 1;
      flip.style.transform = direction < 0 ? "scaleX(-1)" : "scaleX(1)";
      character.classList.add("clippy-state-walking");
      var duration = clamp(distance * 6, 900, 3500);
      root.style.transition = "left " + (duration / 1000) + "s ease-in-out";
      root.style.left = targetLeft + "px";
      setTimeout(function () {
        character.classList.remove("clippy-state-walking");
        resolve();
      }, duration);
    });
  }

  function performSleep() {
    return new Promise(function (resolve) {
      character.classList.add("clippy-state-sleeping");
      showStatus("\uD83D\uDCA4");
      var duration = rand(4000, 7000);
      setTimeout(function () {
        character.classList.remove("clippy-state-sleeping");
        hideStatus();
        resolve();
      }, duration);
    });
  }

  function performPlay() {
    return new Promise(function (resolve) {
      character.classList.add("clippy-state-playing");
      showStatus("\uD83C\uDF89", 1600);
      setTimeout(function () {
        character.classList.remove("clippy-state-playing");
        resolve();
      }, 1600);
    });
  }

  function performHappy() {
    return new Promise(function (resolve) {
      character.classList.add("clippy-state-happy");
      showStatus("\u2764\uFE0F", 1400);
      setTimeout(function () {
        character.classList.remove("clippy-state-happy");
        resolve();
      }, 1400);
    });
  }

  function performRandomActivity() {
    var choices = ["walk", "walk", "play", "sleep", "happy"];
    var choice = choices[randInt(0, choices.length - 1)];
    if (choice === "walk") return performWalk();
    if (choice === "play") return performPlay();
    if (choice === "sleep") return performSleep();
    return performHappy();
  }

  function activityLoop() {
    return wait(rand(6000, 13000)).then(function () {
      if (!document.getElementById("clippy-buddy-root")) return;
      if (isDragging || Date.now() - lastInteraction < 2500) {
        return activityLoop();
      }
      return performRandomActivity().then(activityLoop);
    });
  }
  activityLoop();

  // ---- Health reminders: stand up / move, and drink water ----
  // These fire on their own timers so they show up even if you never
  // interact with Clippy. Each reminder pops the speech bubble, plays a
  // little animation, and shows a status emoji so it's easy to notice.
  function fireReminder(text, emoji) {
    if (!document.getElementById("clippy-buddy-root")) return;
    character.classList.remove("clippy-state-walking", "clippy-state-sleeping", "clippy-state-playing");
    character.classList.add("clippy-state-happy");
    showStatus(emoji, 8000);
    showBubble(text, 8000);
    lastInteraction = Date.now();
    setTimeout(function () { character.classList.remove("clippy-state-happy"); }, 1400);
  }

  function scheduleStandReminder() {
    setTimeout(function () {
      if (!document.getElementById("clippy-buddy-root")) return;
      fireReminder(randomFrom(STAND_TIPS), "\uD83D\uDEB6");
      scheduleStandReminder();
    }, STAND_INTERVAL_MS);
  }

  function scheduleWaterReminder() {
    setTimeout(function () {
      if (!document.getElementById("clippy-buddy-root")) return;
      fireReminder(randomFrom(WATER_TIPS), "\uD83D\uDCA7");
      scheduleWaterReminder();
    }, WATER_INTERVAL_MS);
  }

  scheduleStandReminder();
  scheduleWaterReminder();
})();
