const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path'), fs = require('fs'), { spawn } = require('child_process');
const ffmpeg = require('ffmpeg-static').replace('app.asar', 'app.asar.unpacked');
const { PDFDocument } = require('pdf-lib');
let win;
app.whenReady().then(() => {
  win = new BrowserWindow({ width: 920, height: 720, webPreferences: { preload: path.join(__dirname, 'preload.js') } });
  win.setMenuBarVisibility(false);
  win.loadFile('index.html');
});
app.on('window-all-closed', () => app.quit());

ipcMain.handle('pick', async () => { const r = await dialog.showOpenDialog(win, { properties: ['openFile', 'multiSelections'] }); return r.canceled ? [] : r.filePaths; });
ipcMain.handle('pickDir', async () => { const r = await dialog.showOpenDialog(win, { properties: ['openDirectory'] }); return r.canceled ? null : r.filePaths[0]; });
ipcMain.handle('reveal', (e, p) => shell.showItemInFolder(p));

const AUD = ['mp3', 'wav', 'flac', 'ogg', 'm4a', 'aac', 'opus', 'wma'], IMG = ['jpg', 'jpeg', 'png', 'webp', 'bmp', 'gif', 'tiff'];
const ext0 = f => path.extname(f).slice(1).toLowerCase();
const kind = f => { const e = ext0(f); return e == 'pdf' ? 'pdf' : AUD.includes(e) ? 'audio' : IMG.includes(e) ? 'image' : 'video'; };
const sec = (h, m, s) => +h * 3600 + +m * 60 + +s;

const ff = (args, onP) => new Promise((res, rej) => {
  const p = spawn(ffmpeg, ['-y', '-hide_banner', ...args], { windowsHide: true });
  let dur = 0, err = '';
  p.on('error', rej);
  p.stderr.on('data', d => {
    const s = d.toString(); err = (err + s).slice(-2000);
    const m = s.match(/Duration: (\d+):(\d+):([\d.]+)/); if (m && !dur) dur = sec(m[1], m[2], m[3]);
    const t = [...s.matchAll(/time=(\d+):(\d+):([\d.]+)/g)].pop();
    if (t && dur) onP(Math.min(99, sec(t[1], t[2], t[3]) / dur * 100));
  });
  p.on('close', c => c ? rej(new Error('FFmpeg failed: ' + err.trim().split('\n').slice(-3).join(' '))) : res());
});

const range = (txt, tot) => {
  const ix = [];
  (txt || '1-' + tot).split(',').forEach(p => { const [a, b] = p.split('-').map(v => parseInt(v)); if (!a) return; for (let i = a; i <= (b || a); i++) if (i >= 1 && i <= tot) ix.push(i - 1); });
  if (!ix.length) throw new Error('Invalid page range');
  return ix;
};

ipcMain.handle('run', async (e, { op, files, o, dir }) => {
  const outs = [], errs = [];
  const send = (i, p, n) => win.webContents.send('progress', { i, p, n: n || files.length });
  const d0 = dir || path.dirname(files[0]);
  try {
    if (op == 'pdfmerge') {
      const d = await PDFDocument.create();
      for (const f of files) { const s = await PDFDocument.load(fs.readFileSync(f), { ignoreEncryption: true }); (await d.copyPages(s, s.getPageIndices())).forEach(p => d.addPage(p)); }
      const out = path.join(d0, 'merged.pdf'); fs.writeFileSync(out, await d.save()); outs.push(out);
    } else if (op == 'merge') {
      if (files.length < 2) throw new Error('Add at least two files to merge');
      const k = kind(files[0]);
      if ((k != 'audio' && k != 'video') || files.some(f => kind(f) != k)) throw new Error('Merge needs files of the same type (all audio or all video)');
      const a = k == 'audio', n = files.length;
      let fc = '';
      for (let i = 0; i < n; i++) fc += a ? `[${i}:a]aresample=44100[a${i}];` : `[${i}:v]scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30[v${i}];[${i}:a]aresample=44100[a${i}];`;
      fc += files.map((_, i) => a ? `[a${i}]` : `[v${i}][a${i}]`).join('') + `concat=n=${n}:v=${a ? 0 : 1}:a=1` + (a ? '[a]' : '[v][a]');
      const out = path.join(d0, a ? 'merged.mp3' : 'merged.mp4');
      await ff([...files.flatMap(f => ['-i', f]), '-filter_complex', fc, ...(a ? ['-map', '[a]'] : ['-map', '[v]', '-map', '[a]']), out], p => send(0, p, 1));
      outs.push(out);
    } else {
      for (const [i, f] of files.entries()) {
        try {
          const k = kind(f), name = path.parse(f).name;
          if (op == 'pdfpages') {
            if (k != 'pdf') throw new Error(path.basename(f) + ' is not a PDF');
            const s = await PDFDocument.load(fs.readFileSync(f), { ignoreEncryption: true }), d = await PDFDocument.create();
            (await d.copyPages(s, range(o.pages, s.getPageCount()))).forEach(p => d.addPage(p));
            const out = path.join(d0, name + '_pages.pdf'); fs.writeFileSync(out, await d.save()); outs.push(out); send(i + 1, 0); continue;
          }
          if (k == 'pdf') throw new Error(path.basename(f) + ': use the PDF tools for PDF files');
          let ext = ext0(f), pre = [], post = [];
          if (op == 'convert') {
            ext = o.fmt;
            if (AUD.includes(ext)) post = ['-vn']; else if (ext == 'gif') post = ['-vf', 'fps=12,scale=480:-1:flags=lanczos']; else if (ext == 'jpg') post = ['-q:v', '2'];
          } else if (op == 'trim') {
            if (k == 'image') throw new Error('Trim works on audio and video only');
            const s = +o.start || 0, en = +o.end || 0;
            if (en && en <= s) throw new Error('End must be after start');
            pre = ['-ss', String(s)]; if (en) post = ['-t', String(en - s)];
          } else if (op == 'compress') {
            const lv = o.level, sc = o.maxw > 0 && k != 'audio' ? ['-vf', `scale='min(${o.maxw},iw)':-2`] : [];
            if (k == 'video') { ext = 'mp4'; post = ['-c:v', 'libx264', '-crf', String({ low: 23, med: 28, high: 33 }[lv]), '-preset', 'medium', '-c:a', 'aac', '-b:a', '128k', ...sc]; }
            else if (k == 'audio') { ext = 'mp3'; post = ['-b:a', { low: 192, med: 128, high: 64 }[lv] + 'k']; }
            else { ext = 'jpg'; post = ['-q:v', String({ low: 3, med: 8, high: 15 }[lv]), ...sc]; }
          } else if (op == 'crop') {
            if (k == 'audio') throw new Error('Crop works on images and video only');
            if (!o.w || !o.h) throw new Error('Enter crop width and height');
            post = ['-vf', `crop=${o.w}:${o.h}:${o.x || 0}:${o.y || 0}`]; if (k == 'video') post.push('-c:a', 'copy');
          }
          const out = path.join(d0, `${name}_${op}.${ext}`);
          await ff([...pre, '-i', f, ...post, out], p => send(i, p));
          outs.push(out); send(i + 1, 0);
        } catch (x) { errs.push(x.message); }
      }
    }
  } catch (x) { errs.push(x.message); }
  return { outs, errs };
});
