const { contextBridge, ipcRenderer, webUtils } = require('electron');
contextBridge.exposeInMainWorld('api', {
  pick: () => ipcRenderer.invoke('pick'),
  pickDir: () => ipcRenderer.invoke('pickDir'),
  run: a => ipcRenderer.invoke('run', a),
  reveal: p => ipcRenderer.invoke('reveal', p),
  dropped: fl => [...fl].map(f => webUtils.getPathForFile(f)),
  onProgress: cb => ipcRenderer.on('progress', (e, d) => cb(d))
});
