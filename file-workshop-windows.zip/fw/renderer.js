const $ = s => document.querySelector(s);
const esc = s => s.replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
const G = { convert: ['fmt'], trim: ['t'], compress: ['c'], crop: ['cr'], pdfpages: ['pg'] };
let files = [], dir = null, outs = [];
const view = () => document.querySelectorAll('[data-g]').forEach(e => e.hidden = !(G[$('#op').value] || []).includes(e.dataset.g));
const list = () => { $('#files').innerHTML = files.map((f, i) => `<li><span>${esc(f.split(/[\\/]/).pop())}</span><button data-i="${i}">Remove</button></li>`).join('') || '<li class="mut">No files yet.</li>'; };
$('#op').onchange = view; view(); list();
$('#add').onclick = async () => { files.push(...await api.pick()); list(); };
$('#clr').onclick = () => { files = []; list(); };
$('#files').onclick = e => { if (e.target.dataset.i) { files.splice(+e.target.dataset.i, 1); list(); } };
$('#dirb').onclick = async () => { const d = await api.pickDir(); if (d) { dir = d; $('#dirl').textContent = d; } };
document.addEventListener('dragover', e => e.preventDefault());
document.addEventListener('drop', e => { e.preventDefault(); files.push(...api.dropped(e.dataTransfer.files)); list(); });
api.onProgress(({ i, p, n }) => { $('#bar').value = (i + p / 100) / n * 100; });
$('#res').onclick = e => { if (e.target.dataset.i) api.reveal(outs[+e.target.dataset.i]); };
$('#go').onclick = async () => {
  if (!files.length) { $('#msg').textContent = 'Add files first.'; return; }
  const o = { fmt: $('#fmt').value, start: $('#start').value, end: $('#end').value, level: $('#level').value, maxw: +$('#maxw').value, w: $('#cw').value, h: $('#ch').value, x: $('#cx').value, y: $('#cy').value, pages: $('#pages').value };
  $('#go').disabled = true; $('#bar').hidden = false; $('#bar').value = 0; $('#res').innerHTML = ''; $('#msg').textContent = 'Working...';
  const r = await api.run({ op: $('#op').value, files, o, dir });
  outs = r.outs;
  $('#res').innerHTML = r.outs.map((p, i) => `<li><span>${esc(p.split(/[\\/]/).pop())}</span><a href="#" data-i="${i}">Show in folder</a></li>`).join('') + r.errs.map(m => `<li class="err">${esc(m)}</li>`).join('');
  $('#msg').textContent = `Done: ${r.outs.length} file(s)` + (r.errs.length ? `, ${r.errs.length} error(s)` : '');
  $('#bar').value = 100; $('#go').disabled = false;
};
