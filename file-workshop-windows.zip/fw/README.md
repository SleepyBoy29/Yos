# File Workshop (Windows)

Convert, trim, compress, crop and merge audio, video, images and PDFs. Fully offline; FFmpeg is bundled.

## Run locally (needs Node.js 18+)
    npm install
    npm start

## Build the Windows installer (on a Windows PC)
    npm install
    npm run dist
Output in `dist/`: `File Workshop Setup 1.0.0.exe` (installer) and a portable `.exe`.

## No Windows PC? Use GitHub
Push this folder to a GitHub repo, then open Actions > "Build Windows installer" > Run workflow.
Download the `.exe` from the run's Artifacts.

## Notes
- The installer is unsigned, so Windows SmartScreen will warn ("More info" > "Run anyway").
- Not included yet: Word/Excel/PowerPoint conversion and PDF compression.
